Qwen3-ASR Realtime 无限重复修复

=== 问题 =====================================================================
使用 vllm 部署 Qwen3-ASR realtime 端点时，每段音频的输出会被调度器拼接为
多轮对话历史，导致模型看到自己之前的输出后不断复读。

=== 根因 =====================================================================
scheduler.py 的 _update_request_as_session() 对所有 streaming 请求无条件将
上一轮的 output tokens 拼接到下一轮 prompt 前面。

Qwen3-ASR 是单轮模型，不期望多轮历史，导致模型被自己的输出干扰。

=== 修改文件 =================================================================
1. vllm/model_executor/models/interfaces.py
   - SupportsRealtime 协议新增 realtime_reset_context: bool = False

2. vllm/model_executor/models/qwen3_asr_realtime.py
   - 设置 realtime_reset_context = True
   - buffer_realtime_audio() 消费 input_stream 防止队列泄漏

3. vllm/v1/core/sched/scheduler.py
   - __init__ 中缓存 realtime_reset_context 标志
   - _update_request_as_session() 检查标志，True 时跳过历史拼接

4. vllm/entrypoints/speech_to_text/realtime/connection.py
   - 使用 get_streaming_post_processor_cls() 后处理 delta

=== 应用方式 =================================================================
方式一：打 patch（推荐）
  cd /path/to/vllm
  git apply 0001-fix-qwen3-asr-realtime-reset-context.patch

方式二：直接替换文件
  - interfaces.py       → vllm/model_executor/models/interfaces.py
  - qwen3_asr_realtime.py → vllm/model_executor/models/qwen3_asr_realtime.py
  - scheduler.py         → vllm/v1/core/sched/scheduler.py
  - connection.py        → vllm/entrypoints/speech_to_text/realtime/connection.py

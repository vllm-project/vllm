"""Recompute fixed-depth and cross-depth signatures from raw result JSON."""
import argparse
import collections
import itertools
import json
from pathlib import Path

def summarize(paths):
    runs = []
    references = []
    for path in paths:
        d = json.loads(path.read_text())
        refs, counts = {}, collections.Counter()
        modes = collections.defaultdict(collections.Counter)
        for item in d["records"]:
            key = item["case"], item["temperature"]
            if item["kind"] == "cold_reference":
                refs[key] = item
                continue
            x = refs[key]["result"]["signature"]
            y = item["result"]["signature"]
            checks = {"comparisons": 1, "exact": x == y,
                      "tokens": x["token_ids"] == y["token_ids"],
                      "logprobs": x["logprobs"] == y["logprobs"]}
            counts.update(checks)
            modes["greedy" if key[1] == 0 else "sampled"].update(checks)
        expected = d.get("expected_comparisons", len(refs) * 8)
        if d["status"] != "error":
            assert counts["comparisons"] == expected
        row = {"model": d["model"], "mtp": d.get("mtp"), "source": str(path),
               "status": d["status"], **counts, "strata": dict(modes)}
        runs.append(row)
        references.append(refs)
    cross = []
    for i, j in itertools.combinations(range(len(runs)), 2):
        if runs[i]["model"] != runs[j]["model"] or runs[i]["mtp"] == runs[j]["mtp"]:
            continue
        records = []
        for key in sorted(references[i].keys() & references[j].keys()):
            a, b = references[i][key], references[j][key]
            if a["prompt_token_ids"] != b["prompt_token_ids"]:
                continue
            x, y = a["result"]["signature"], b["result"]["signature"]
            equal = x["token_ids"] == y["token_ids"]
            divergence = next((k + 1 for k, (u, v) in enumerate(
                zip(x["token_ids"], y["token_ids"])) if u != v), None)
            if divergence is None and not equal:
                divergence = min(len(x["token_ids"]), len(y["token_ids"])) + 1
            records.append({
                "case": key[0], "temperature": key[1], "exact": x == y,
                "tokens_equal": equal, "logprobs_equal": x["logprobs"] == y["logprobs"],
                "first_different_token_1based": divergence,
                "max_selected_logprob_delta_when_tokens_equal":
                    max((abs(u-v) for u, v in zip(x["logprobs"]["token_logprobs"],
                                                  y["logprobs"]["token_logprobs"])), default=0)
                    if equal else None,
                "left_text": x["text"], "right_text": y["text"],
            })
        modes = {}
        for temp, mode in ((0, "greedy"), (0.8, "sampled")):
            rows = [r for r in records if r["temperature"] == temp]
            modes[mode] = {"comparisons": len(rows), "exact": sum(r["exact"] for r in rows),
                          "tokens": sum(r["tokens_equal"] for r in rows),
                          "logprobs": sum(r["logprobs_equal"] for r in rows)}
        cross.append({"model": runs[i]["model"], "left": runs[i]["mtp"],
                      "right": runs[j]["mtp"], "strata": modes, "records": records})
    return {"runs": runs, "cross_mtp": cross}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inputs", nargs="+", type=Path)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    output = json.dumps(summarize(args.inputs), ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(output)
    else:
        print(output, end="")

if __name__ == "__main__":
    main()

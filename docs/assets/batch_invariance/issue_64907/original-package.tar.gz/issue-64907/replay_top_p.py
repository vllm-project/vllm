"""Replay the first sampling divergence using a compact real CUDA input.

Run with the tested vLLM environment and the tested BI overlay on PYTHONPATH.
The original sampler source is loaded separately so the adaptive behavior can
still be reproduced after the fix has been installed.
"""
import argparse
import importlib.util
import json
from pathlib import Path

import torch
from vllm.model_executor.layers.batch_invariant import init_batch_invariance

init_batch_invariance()
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "original_top_p_sampler", root / "sampling" / "topk_topp_sampler.original.py")
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
from vllm.v1.sample.ops.topk_topp_sampler import apply_top_k_top_p as fixed

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--fixture", type=Path, required=True,
                    help="Separately obtained authorized experimental tensor fixture")
args = parser.parse_args()
fixture = torch.load(args.fixture, weights_only=True)
single = fixture["scaled_logits"].cuda().unsqueeze(0)
batch = single.expand(8, -1).clone()
results = []
for name, function in (("original_adaptive", original.apply_top_k_top_p),
                       ("fixed_bi", fixed)):
    masks = []
    for values in (single, batch):
        p = torch.full((len(values),), fixture["top_p"],
                       dtype=values.dtype, device=values.device)
        masks.append(torch.isfinite(function(values.clone(), None, p))[0].cpu())
    results.append({
        "mode": name,
        "masks_equal": torch.equal(*masks),
        "different_mask_elements": (masks[0] != masks[1]).sum().item(),
        "single_matches_observed": torch.equal(masks[0], fixture["single_mask"]),
        "batch_matches_observed": torch.equal(masks[1], fixture["batch_mask"]),
    })
assert results[0]["different_mask_elements"] == 2, results
assert results[0]["single_matches_observed"] and results[0]["batch_matches_observed"]
assert results[1]["masks_equal"], results
print(json.dumps(results, indent=2))

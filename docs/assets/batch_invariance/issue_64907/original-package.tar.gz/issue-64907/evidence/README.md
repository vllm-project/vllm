# Published evidence

validation-summary.json is recomputed from the historical final-validation files. comparison-audit.json retains each compared response's canonical JSON SHA256 (UTF-8, ensure_ascii=False, sort_keys=True, separators=(',', ':')), token/logprob hashes, case, decoding temperature and request kind. Source-file digests identify the withheld raw files.

The summary separates the final eight-file experiment (1984 comparisons / 11 groups) from the earlier six-file 2B MTP1 result (128 comparisons). References are excluded from comparison denominators. Cross-depth rows include numeric deltas and first divergence positions; raw generated text and tensor fixtures are withheld. Hash equality audits the recorded observations but cannot independently establish their origin or rerun the GPU computation.

Mixed batches were cache-primed. Cold mixed batches, full-vocabulary logits, vision, multi-GPU, CUDA Graph, upstream-main compatibility, and MTP0/cross-depth losslessness were not established. Portable helpers have not been GPU rerun during packaging.

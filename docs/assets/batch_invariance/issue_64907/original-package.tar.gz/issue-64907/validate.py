import os
import concurrent.futures as cf
import json
import re
import threading
import time
from pathlib import Path
from urllib.request import Request, urlopen
from openai import OpenAI
from transformers import AutoTokenizer

BASE = os.environ.get("BASE_URL", "http://127.0.0.1:8000").rstrip("/")
OUTPUT = Path(os.environ["RESULT_DIR"])/"final-validation.json"
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
client = OpenAI(base_url=BASE + "/v1", api_key="local", timeout=300)
tokenizer = AutoTokenizer.from_pretrained(os.environ["MODEL_PATH"])
records = []
result = {"model": os.environ["MODEL_NAME"], "mtp": int(os.environ["MTP"]), "prefix_cache": True,
          "batch_invariant": True, "records": records}
stop = threading.Event()
peak = 0

def metrics():
    text = urlopen(BASE + "/metrics", timeout=5).read().decode()
    values = {}
    for line in text.splitlines():
        if line.startswith("#"):
            continue
        m = re.match(r"([^ {]+)(?:\{[^}]*\})? ([\d.eE+-]+)", line)
        if m and any(x in m[1] for x in ("prefix_cache", "spec_decode", "num_requests",
                                         "generation_tokens", "prompt_tokens", "cache_usage")):
            values[m[1]] = values.get(m[1], 0) + float(m[2])
    return values

def monitor():
    global peak
    while not stop.is_set():
        try:
            peak = max(peak, metrics().get("vllm:num_requests_running", 0))
        except Exception:
            pass
        stop.wait(0.05)

def reset():
    return urlopen(Request(BASE + "/reset_prefix_cache", method="POST"),
                   timeout=10).read().decode()

def save():
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2))

def send(prompt, temperature):
    start = time.perf_counter()
    raw = client.completions.create(
        model=os.environ["MODEL_NAME"], prompt=prompt, temperature=temperature,
        top_p=0.9 if temperature else 1.0, seed=42, max_tokens=64,
        logprobs=5, extra_body={"return_token_ids": True, "ignore_eos": True},
    ).model_dump()
    choice = raw["choices"][0]
    signature = {k: choice.get(k) for k in ("text", "token_ids", "logprobs", "finish_reason")}
    assert signature["token_ids"] and signature["logprobs"]
    return {"signature": signature, "usage": raw["usage"],
            "latency_s": time.perf_counter() - start}

def compare(a, b):
    x, y = a["signature"], b["signature"]
    deltas = [abs(i-j) for i,j in zip(x["logprobs"]["token_logprobs"],
                                     y["logprobs"]["token_logprobs"])]
    return {"exact": x == y, "tokens_equal": x["token_ids"] == y["token_ids"],
            "logprobs_equal": x["logprobs"] == y["logprobs"],
            "max_logprob_delta": max(deltas, default=0)}

def chat_ids(content):
    encoded = tokenizer.apply_chat_template([{"role": "user", "content": content}],
              tokenize=True, add_generation_prompt=True, enable_thinking=False)
    return encoded["input_ids"] if hasattr(encoded, "keys") else encoded

try:
    result["metrics_before"] = metrics()
    threading.Thread(target=monitor, daemon=True).start()
    base = chat_ids("请根据具体证据说明广告审核原则。")
    repeated = tokenizer.encode(" evidence", add_special_tokens=False)
    assert len(repeated) == 1
    cases = {"short": base}
    # Insert one-token fillers before the user query. Exactly sized inputs
    # straddle the hybrid cache's runtime-detected token alignment boundary.
    alignment = int(os.environ["CASE_ALIGNMENT"])
    runtime_alignment = int(os.environ["CACHE_ALIGNMENT"])
    result["runtime_cache_alignment"] = runtime_alignment
    result["cache_alignment"] = alignment
    lengths = [alignment-1, alignment, alignment+1, 2*alignment-1, 2*alignment, 2*alignment+1, 2442]
    if runtime_alignment != alignment:
        lengths += [runtime_alignment-1, runtime_alignment, runtime_alignment+1,
                    2*runtime_alignment-1, 2*runtime_alignment, 2*runtime_alignment+1]
    for length in dict.fromkeys(lengths):
        cases[f"boundary_{length}"] = base[:3] + repeated * (length-len(base)) + base[3:]
        assert len(cases[f"boundary_{length}"]) == length
    for temperature in (0.0, 0.8):
        for name, target in cases.items():
            reset()
            reference = send(target, temperature)
            result["expected_comparisons"] = len(cases)*2*8
            records.append({"case": name, "temperature": temperature, "kind": "cold_reference",
                            "prompt_token_ids": target, "result": reference})
            # Cold and warm cache must reproduce the same complete response.
            for kind in ("warm_repeat", "cold_repeat"):
                if kind == "cold_repeat":
                    reset()
                observed = send(target, temperature)
                comparison = compare(reference, observed)
                records.append({"case": name, "temperature": temperature, "kind": kind,
                                "comparison": comparison, "result": observed})
                print("COMPARE", name, temperature, kind, comparison, flush=True)
                save()
            for size in (2, 4, 8):
                for position in sorted({0, size-1}):
                    prompts = [chat_ids(f"任务{i}：" + "背景。"*(43*i) +
                                       "写一段详细的天气描述。") for i in range(size-1)]
                    prompts.insert(position, target)
                    barrier = threading.Barrier(size)
                    def dispatch(item):
                        barrier.wait()
                        return send(item, temperature)
                    with cf.ThreadPoolExecutor(max_workers=size) as pool:
                        observed = list(pool.map(dispatch, prompts))
                    comparison = compare(reference, observed[position])
                    records.append({"case": name, "temperature": temperature,
                                    "kind": "mixed_concurrent", "size": size,
                                    "position": position, "comparison": comparison,
                                    "result": observed[position]})
                    print("COMPARE", name, temperature, size, position, comparison, flush=True)
                    save()
    result["metrics_after"] = metrics()
    checks = [r["comparison"] for r in records if "comparison" in r]
    before, after = result["metrics_before"], result["metrics_after"]
    result["metrics_delta"] = {k: v-before.get(k, 0) for k,v in after.items()}
    result["summary"] = {"comparisons": len(checks), "exact_matches": sum(r["exact"] for r in checks),
                         "token_matches": sum(r["tokens_equal"] for r in checks),
                         "peak_running": peak}
    result["status"] = "passed" if all(r["exact"] for r in checks) else "failed"
except Exception as error:
    result["status"], result["error"] = "error", repr(error)
    raise
finally:
    stop.set()
    result["peak_running"] = peak
    save()
    print("FINAL", {k:result[k] for k in ("status", "summary", "error") if k in result}, flush=True)

# Upstream submission preparation

## Published umbrella issue

https://github.com/vllm-project/vllm/issues/64907

**Title:** Batch-invariant Qwen GDN with prefix caching and MTP

Qwen GDN models using hybrid FullAttention/Mamba caches can produce different responses for the same prompt when prefix reuse, mixed request batches and MTP interact. We prepared a guarded eager fallback, cache/state fixes, a fixed gated normalization layout and stable top-p filtering.

This bundle targets the eight original wheel source files listed in `manifest.json` (vLLM 0.24.0+cu129). No upstream Git commit was recorded. Please identify an upstream base and port/revalidate the changes before creating a PR against main.

### Expected behavior

For a fixed checkpoint, tokenizer, MTP depth and decoding configuration, repeated cold/warm prefix-cache requests and mixed batches should return identical text, token IDs, complete returned top-5 logprobs and finish reasons. Seed equivalence across different MTP depths is a separate property.

### Observed failures and fixes

1. **GDN execution and speculative gate indexing.** Preserve CPU sequence offsets and dispatch convolution/recurrent/prefill kernels per request in BI mode. Select speculative gates with the same `spec_token_indx` as q/k/v. Retain capability checks, an explicit experiment guard and rejection of unvalidated full CUDA Graph execution.
2. **Hybrid prefix hits.** When no group is explicitly marked EAGLE, do not apply last-block pruning fallback to Mamba groups. Hit-length coordination must never grow a shortened candidate; FullAttention block lists must cover the final hit length. A 1088-token warm-prefix 2B reproducer returned an empty FullAttention prefix list while the scheduler skipped 544 cached tokens.
3. **Async accepted-count ownership.** GPU-to-CPU accepted counts belong to the previous request layout. Copy them into a separate pinned snapshot, synchronize, then remap previous positions to the current batch. InputBatch mutation must not overwrite the in-flight snapshot. The historical 1087-token stress reproduction passed 19/20 before the fix; no individual causal ablation of that failing iteration was performed.
4. **Gated norm layout.** For a real 9B layer, identical inputs/gates produced one BF16 element differing by 6.103515625e-5 when the row-count-dependent layout switched from 1 to 2 rows per block. Replay using runtime BF16 weights reproduced the difference; fixed layout matched. BI mode now fixes rows per block to 1.
5. **Top-p backend and ties.** At the first 9B sampling divergence, raw logits, draft token and RNG offset matched. The adaptive PyTorch/Triton helper switched two equal-logit tokens at the top-p boundary between B1 and B8. BI CUDA uses a single PyTorch path and stable sorting. `replay_top_p.py`, when supplied with the separately authorized real tensor fixture, reproduces the two mask differences before the fix and equality after it.
6. **Cache instrumentation.** The scheduler audit measures unique active physical block IDs and is disabled for performance and MTP234 consistency runs. It should be reviewed separately as diagnostic/test instrumentation.

### Validation performed on 2026-10-31

Single H100 80GB, text input, eager, FA3, BF16 activations, Torch 2.11.0+cu129, Transformers 5.22.1, Triton 3.6.0, flashinfer-python 0.6.12. The 27B directory name is `Qwen3.8-27B-FP8`; its config declares `Qwen3_5ForConditionalGeneration`. The name is an experimental checkpoint identifier, not evidence of an official architecture/version label.

| Model identifier | MTP1 | MTP2 | MTP3 | MTP4 |
|---|---:|---:|---:|---:|
| Qwen3.5-2B | 128/128 | 128/128 | 224/224 | 224/224 |
| Qwen3.5-9B | 128/128 | 224/224 | 224/224 | 224/224 |
| Qwen3.8-27B-FP8 | 128/128 | 128/128 | 128/128 | 224/224 |

MTP1 2B used the earlier six-file patch; larger models and all MTP234 groups used the final eight-file patch. The 12 group totals are 2112 exact fixed-depth comparisons across stages, not 2112 comparisons on a single common patch/version, and exclude cold reference responses from the denominator. The final eight-file version alone accounts for 1984/1984 comparisons in 11 groups.

Greedy and temperature=0.8/top_p=0.9/seed=42 were tested; 64 output tokens; cold repeat, warm repeat and cache-primed mixed B2/B4/B8 target-first/target-last; a full cold mixed-batch matrix was not tested. Runtime cache boundaries were checked, with ±1 and double-boundary ±1 inputs. Each group recorded peak eight overlapping requests. Draft generation, accepted tokens and prefix hits confirmed the features were actually active. Target and draft FP8 layer weights remained FP8 (256 and 4 runtime layers).

MTP1 performance was measured using 3 post-warmup rounds and fixed 256-token outputs. 2B MTP throughput change was +31.8% to +94.6%, 9B +51.3% to +106.4%, 27B +55.1% to +120.7%. These are workload-specific measurements, with differing outputs in some MTP0 controls. MTP234 performance/memory was not remeasured.

### Known limits: do not claim lossless MTP equivalence

- 2B greedy MTP2 vs MTP3/4: all 8 shared token sequences match, but only 5/8 complete responses match; maximum selected-token logprob delta 0.0931459665.
- 9B greedy MTP2/3/4: all 14 shared references per pair match exactly.
- 27B greedy MTP2 vs MTP3: 8/8 exact. MTP4 vs MTP2 or 3: 5/8 token sequences match; 1600/1601/2442-token prompts diverge at output positions 35/6/6.
- Every tested sampled reference across MTP depths has a different token sequence despite the same seed. RNG-consumption and distribution equivalence have not been established for these depth comparisons.
- MTP1 vs disabled-MTP 256-token controls match 57/78 sequences for 9B and 30/78 for 27B. These are not full-logprob comparisons.
- No proof for all prompts, CUDA Graph, vision input, multi-GPU, production pressure or longer outputs; split patches have not been individually GPU-ablated.

### Reproduction

See `README.md`, `manifest.json`, `serve.py`, `validate.py`, `summarize.py` and `replay_top_p.py`. Patch application and SHA256 reconstruction were checked locally during packaging; portable launcher dry-run and raw-result recomputation are packaging checks, not a new GPU test.

### Suggested PR sequence

| Suggested title | Patch | Scope notes |
|---|---|---|
| Preserve hybrid prefix-hit monotonicity with MTP | `patches/02-hybrid-prefix-cache.patch` | Review Mamba/EAGLE assumptions and non-BI behavior |
| Snapshot async accepted counts before InputBatch remapping | `patches/03-accepted-count-snapshot.patch` | Add request add/remove/condense/swap coverage |
| Add guarded eager batch-invariant Qwen GDN fallback | `patches/01-gdn-batch-invariance.patch` | Separate unconditional gate correctness change when porting; agree on official capability/env API |
| Fix gated norm layout in batch-invariant mode | `patches/04-fixed-gated-norm-layout.patch` | Assess all callers and performance costs |
| Stabilize CUDA top-p filtering for batch invariance | `patches/05-stable-top-p.patch` | Include real-tensor tie-boundary reproduction and BI-off checks |
| Add active hybrid-cache physical-block diagnostics | `patches/90-cache-measurement.patch` | Keep instrumentation separate from production correctness |

PR test plan: reproduce the minimal failures, add upstream regression tests, apply the dependent correctness changes together, rerun fixed-depth matrices, and report remaining cross-depth/disabled-MTP differences explicitly. Treat the supplied individual diffs as review units, not proof that each patch alone is sufficient.

The umbrella issue is published at https://github.com/vllm-project/vllm/issues/64907. This repository publishes supporting material; no upstream code PR has been created. Tensor fixtures and raw responses are omitted; see README.md and evidence/README.md.

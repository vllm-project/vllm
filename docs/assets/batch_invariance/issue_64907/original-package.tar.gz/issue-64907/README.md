# Qwen GDN prefix cache + MTP + batch invariance

Experimental patch and reproduction materials for [vLLM issue #64907](https://github.com/vllm-project/vllm/issues/64907).
No upstream code PR has been published. This is a wheel-source experiment, not an upstream port.

The final eight-file patch passed **1984/1984 fixed-depth comparisons in 11 groups**.
The historical 2112 total also includes 128 comparisons on an earlier six-file 2B MTP1 patch.
See [evidence/validation-summary.json](evidence/validation-summary.json) and
[evidence/comparison-audit.json](evidence/comparison-audit.json) for independently recomputed counts
and per-response digests. Cross-depth/disabled-MTP equivalence remains unproven.

Read [COMMUNITY_SUBMISSION.md](COMMUNITY_SUBMISSION.md) for evidence and limitations,
[SOLUTION.zh-CN.md](SOLUTION.zh-CN.md) for detailed Chinese instructions and file changes,
[patch-inventory.json](patch-inventory.json) for exact hunks and SHA256,
and [packaging-verification.json](packaging-verification.json) for local patch checks.

Tested baseline: vLLM 0.24.0+cu129 wheel, exact eight original source hashes in manifest.json;
Torch 2.11.0+cu129 / Transformers 5.22.1 / Triton 3.6.0 / flashinfer-python 0.6.12,
Linux x86_64, H100 80GB, CUDA 12.9 compiler, FA3, eager. A matching GPU environment
and the actual checkpoint/tokenizer are prerequisites. No Git base commit was recorded.

```bash
python apply_overlay.py --source /path/to/site-packages/vllm --overlay /path/to/new-overlay
python serve.py --overlay /path/to/new-overlay --model /models/Qwen3.5-9B \
  --served-model-name Qwen3.5-9B --mtp 2
```

Wait for `/health`, read actual runtime cache alignment from `/server_info` or server logs,
then run in a second terminal:

```bash
MODEL_NAME=Qwen3.5-9B MODEL_PATH=/models/Qwen3.5-9B MTP=2 \
CASE_ALIGNMENT=528 CACHE_ALIGNMENT=544 RESULT_DIR=/tmp/qwen9b-mtp2 \
BASE_URL=http://127.0.0.1:8000 python validate.py
python summarize.py /tmp/qwen9b-mtp2/final-validation.json
```

544 is the recorded 9B MTP2 alignment, not an assumed value for every runtime.
Case baselines are 544/528/800 for the 2B/9B/27B checkpoint identifiers; use actual
alignment for CACHE_ALIGNMENT and preserve baseline inputs for cross-depth matching.

```bash
VLLM_BATCH_INVARIANT=1 PYTHONPATH=/path/to/new-overlay python replay_top_p.py --fixture /path/to/authorized/top-p-fixture.pt
python summarize.py /tmp/qwen9b-mtp2/final-validation.json \
  /tmp/qwen9b-mtp3/final-validation.json --output /tmp/cross.json
```

The server binds localhost and enables development endpoints for this reproduction.
CUDA_HOME and LD_LIBRARY_PATH are inherited, not hardcoded to the experiment host.
The portable helpers were syntax/dry-run/result checked during packaging, not GPU rerun.

`vllm-0.24.0-cu129.patch` uses wheel-package paths; `patches/vllm-repository.patch`
uses paths from the upstream repository root. The six numbered split diffs together
reconstruct the exact tested patch. The optional scheduler audit is instrumentation,
not a correctness fix; review it separately. Split diffs were not individually GPU ablated.

FP8 dynamic-wrapper source under reference/runtime-sources is baseline code, not
a new patch. `reference/install_cuda_toolchain.py` preserves the original isolated
CUDA installer and assumes a fresh /tmp/qwen-cuda-12.9 directory; it is not required
when the host already has a working matching toolchain. Do not transplant host driver libraries.

License/provenance: vLLM-derived sources and patches retain upstream SPDX/copyright
headers and Apache-2.0 terms; see [NOTICE](NOTICE). Model weights, raw generated responses,
and model-derived tensor fixtures are omitted because the experimental checkpoint's
original public URL and redistribution terms were not recorded. Replay requires a separately
obtained, authorized tensor fixture; its original digest remains in PROVENANCE.json.
Published evidence includes numeric summaries and hashes, not recoverable raw responses.
A fresh GPU run still requires the matching checkpoint/tokenizer and environment.

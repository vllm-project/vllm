# 完整解决方案与社区提交说明

本方案的目标是：在 Qwen GDN 混合注意力模型中同时开启 prefix cache、MTP 和 batch invariance，并使**固定 MTP 深度内**的缓存复用及混合批次请求得到相同的完整响应。现有实现已完成单 H100、文本输入、eager 模式下的有限矩阵验证；跨 MTP 深度及相对 MTP 关闭的无损等价仍未解决。

## 1. 实际测试的版本与依赖

基准为 vLLM 0.24.0+cu129 wheel 源文件，Python 3.11.2、PyTorch 2.11.0+cu129、Transformers 5.22.1、Triton 3.6.0、flashinfer-python 0.6.12。GPU 为 H100 80GB；CUDA 编译器 12.9.86、cudart 12.9.79、CCCL 12.9.27。完整八文件原始/目标 SHA256 见 `manifest.json`。

版本号不能代替源码身份：未记录对应的上游 Git commit，本交付以原始八文件 SHA256 为唯一已核对的应用基线。社区移植到其他 tag/commit 前需重新核对函数与调用约定；不能把对这个 wheel 的通过结果声明为上游 main 的通过结果。

三个 checkpoint 的实验目录名为 Qwen3.5-2B、Qwen3.5-9B、Qwen3.8-27B-FP8。后两者 config 的架构字段均为 `Qwen3_5ForConditionalGeneration`；“Qwen3.8”在此仅是给定目录标识，不据此认定官方架构版本。复现需取得相同 checkpoint 与 tokenizer；不能只替换为近似模型名。

## 2. 缺陷链与处理顺序

```mermaid
flowchart TD
    A[启动能力保护与元数据] --> B[逐请求 GDN 卷积、递推、prefill]
    B --> C[spec gates 与 q/k/v 使用相同索引]
    C --> D[Hybrid prefix 命中长度只能缩短]
    D --> E[接受长度 D2H 独立快照及请求映射]
    E --> F[门控 RMSNorm 固定布局]
    F --> G[top-p 统一后端及稳定排序]
    G --> H[固定 MTP 深度内完整矩阵验证]
    H --> I[跨深度差异继续单独排查]
```

只解除 speculative GDN 的启动保护会允许不完整的执行路径进入运行，无法替代后续状态与数值修复。处理应同时覆盖请求切片、gates 索引、缓存协调及异步接受长度映射，然后处理行数依赖的 norm 与采样分歧。

## 3. 八个补丁文件的完整改动清单

下列路径相对于上游仓库根目录。实际 wheel 内路径需去掉前面的 `vllm/`；交付提供两种路径格式的完整 diff。

| 文件 | 类 / 函数 / 位置 | 实际改动 | 解决的问题与证据 | 适用范围 / 注意点 |
|---|---|---|---|---|
| `vllm/model_executor/layers/mamba/gdn/base.py` | `GatedDeltaNetAttention.__init__`、`supports_batch_invariant` | 默认能力为 false；BI 模式校验实现能力；speculative 路径必须显式开启 `QWEN35_BI_MTP_EXPERIMENT=1` | 防止所有 GDN 派生类被一概放行；Qwen 实现完成后才声明支持 | 自定义环境变量是实验开关，尚未加入上游统一 env 注册；上游需要确认正式能力接口 |
| `vllm/v1/attention/backends/gdn_attn.py` | backend 能力方法、`GDNAttentionMetadata`、metadata builder 初始化及 `build` | 声明 batch invariance 能力；保存 spec/non-spec/prefill 的 CPU packed offsets；校验实验开关；BI+full CUDA Graph 直接拒绝 | 为逐请求切片提供与调度一致的边界；防止未经验证的 graph replay | 本方案只验证 eager；复制 offsets 带来 CPU 工作，不是新的高效批量 kernel |
| `vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py` | `QwenGatedDeltaNetAttention` 初始化、输入投影、`_bi_decode_recurrence`、`_forward_core` | Qwen 声明 BI 支持；要求 CUDA、拒绝 cutedsl prefill；BI 关闭 packed recurrent decode；按 metadata 分段输入投影；普通/spec 卷积、decode 递推、prefill chunk 按请求执行并合并输出；每请求传对应状态槽与接受长度；speculative `a/b` 按 `spec_token_indx` 取值，与 q/k/v 顺序一致 | packed 请求行数与状态映射影响数值；混合 prefill/spec 时 gates 与 q/k/v 不能错配。联合修复后 2B 128/128，后续八文件版本九组1728/1728 | gates 索引修复也进入非 BI speculative 分支，不能说所有非 BI 路径都完全未改；需在上游增加混合请求及空分段覆盖 |
| `vllm/v1/core/kv_cache_coordinator.py` | coordinator 初始化、hybrid hit lookup | `use_eagle` 且没有显式 EAGLE 组时，fallback 排除 `MambaSpec`；检查 lookup 不得增加候选命中长度；最终验证 FullAttention 组块数覆盖命中长度 | 2B 1088-token 热缓存：GDN checkpoint 正确，但协调器先缩短再增大命中长度，返回的 FullAttention 前缀块为空；scheduler 跳过 prefix 计算后读错 K/V。修复后 1088 专项一致、矩阵126/128 | 缓存协调修复不以 BI 为唯一门槛；当前 coverage 检查用 RuntimeError，移植需确认所有 hybrid/cache spec 的语义 |
| `vllm/v1/worker/gpu_model_runner.py` | runner 初始化、GDN preprocess、接受长度事件同步路径 | BI+实验开关+MTP+async+Mamba align 时分配专用 pinned CPU 接受长度快照；D2H 写快照，事件同步后经上一轮 `prev_positions` 映射到当前请求；新请求填1，之后更新 input batch 数组 | D2H 结果属于上一轮布局，而 `InputBatch.add/condense/swap` 可改写同一数组。2B 1087 专项19/20；加入快照后完整矩阵128/128 | 对历史第11次专项失败没有逐事件因果消融；联合回归支持此修复，不等于独立证明每次失败都由该竞态造成 |
| `vllm/model_executor/layers/fla/ops/layernorm_guard.py` | `calc_rows_per_block` | BI 时固定返回1，其他模式保留原自适应布局 | 9B真实第26层 input/gate 一样；M=64布局1与M=512布局2，1个BF16元素差6.103515625e-5；使用运行时BF16 norm权重回放复现并修复 | 函数影响所有调用方，不只 Qwen；需衡量 wider shapes 的性能。随机探针通过不能替代真实张量回放 |
| `vllm/v1/sample/ops/topk_topp_sampler.py` | `apply_top_k_top_p`、PyTorch过滤函数 | BI+CUDA统一调用PyTorch过滤，避免≥8行转Triton；BI的 logits 排序设置 `stable=True` | 9B首次分叉 raw logits、draft、RNG offset 相同，两个并列logit token在top-p边界交换；真实输入回放只有2个mask元素不同，固定后精确一致；最终9B/27B各128/128 | 直接张量根因回放覆盖9B，27B依据同形态及修复后回归；跨 MTP 深度 RNG 序列等价未由此证明 |
| `vllm/v1/core/sched/scheduler.py` | `schedule` 结束、`_update_after_schedule` 后 | 可选 `QWEN35_CACHE_AUDIT_PATH` 输出物理块并集、引用数、每请求进度、池字节、分组信息 | 正确量化共享前缀活跃缓存占用；避免 nvidia-smi / 预分配池误判 | 这是测量 instrumentation，**不是一致性修复**；吞吐和MTP234阶段关闭；上游建议独立放测试/诊断模块 |

逐行 diff 是改动的最终依据。`patch-inventory.json` 保存每文件 additions/deletions、hunk 起点、原始/目标 SHA256；完整源码快照保留在原 MTP 证据目录。社区目录不包含模型权重、内部平台命令或完整系统环境转储。

## 4. FP8 与环境问题的完整处理

27B 的目标 256 个 FP8 层、草稿4个 FP8层在 MTP=1/2/3/4 运行时均保留 `torch.float8_e4m3fn`，block大小128×128；嵌入/归一化等未量化层可使用BF16。

DeepGEMM 首次 JIT 在NVCC12.6下出现 `ld_st.cuh` 128-bit asm `q`约束编译失败。实际处理是在独立目录安装官方 CUDA12.9工具链、核对各组件SHA256，并补齐拆分安装的 `lib64 -> lib` 布局供 `-lcudart` 链接。没有将FP8权重解量化到BF16。交付保留当时的组件版本、URL、hash与安装脚本。

FP8 dynamic wrapper 中 BI 分支固定走 DeepGEMM，避免按M<32切swapAB；这段来自**基线wheel已有实现**，不在八文件补丁内。`reference/runtime-sources/`保存当时只读源码供审核；不能把它列为本次新增改动。运行时kernel对象类型与实际dtype有证据，但未进行底层GPU kernel profiler逐调用验证。

MTP234期间系统NVML软链接解析到空占位库，后续七组初始化失败。实际恢复仅在独立目录复制匹配535.129.03驱动的有效NVML库，并将其加入进程 `LD_LIBRARY_PATH`，同时使用CUDA兼容库；NVML初始化、1张H100识别和CUDA张量计算均通过。此环境处理不属于vLLM源码补丁。社区应使用本机匹配驱动，不复制或硬编码实验机器的535版本。便携入口默认继承用户的CUDA/驱动配置。

## 5. 可直接复现的材料与命令

`community` 是提交准备目录，含完整wheel patch、仓库路径patch、六个拆分patch、SHA manifest、安装器、便携启动入口、完整一致性驱动、结果重算脚本、top-p回放脚本、数值证据摘要与英文问题说明；模型派生张量及原始生成响应未公开。

### 5.1 在全新环境创建隔离overlay

先准备与实验相符的GPU软件环境和checkpoint，再从**尚未打补丁**的wheel包取源码。以下命令在本目录执行：

```bash
python apply_overlay.py --source /path/to/site-packages/vllm --overlay /path/to/new-qwen-overlay
```

安装器先核对全部8个原始hash，拒绝覆盖已存在overlay；复制wheel源码、应用完整patch，再核对8个目标hash并编译Python。包中的 `packaging-verification.json` 记录此次本地重建/反向校验结果。解除overlay只需停止使用该目录的PYTHONPATH；没有覆盖原环境。

若从上游仓库移植，先核对manifest对应文件，然后查看仓库格式diff：

```bash
git apply --check /path/to/community/patches/vllm-repository.patch
git apply /path/to/community/patches/vllm-repository.patch
```

这两步属于给社区维护者的操作示例，本次没有替用户执行Git提交或发布PR。只有8个源文件匹配时才能期望目标hash一致；不同commit需要人工重基并重新验证。

### 5.2 启动三项全开的实验服务

```bash
python serve.py --overlay /path/to/new-qwen-overlay --model /models/Qwen3.5-9B \
  --served-model-name Qwen3.5-9B --mtp 2 --port 8000
```

入口设置 `VLLM_BATCH_INVARIANT=1`、`QWEN35_BI_MTP_EXPERIMENT=1`、`VLLM_USE_FLASHINFER_SAMPLER=0`。启动 prefix cache、Mamba align、MTP、FA3、eager；max_model_len5120、max_num_seqs32、max_num_batched_tokens8192、util0.8。`--mtp`可选1/2/3/4。继承现有 `CUDA_HOME` 和 `LD_LIBRARY_PATH`，不硬编码内部机器目录。

本实验为清缓存及读取server_info使用 `VLLM_SERVER_DEV_MODE=1`，入口固定绑定localhost。这个开发接口是复现测试需要，不应自动带入公开生产服务。`--dry-run`仅打印命令，可在无GPU环境核对配置。

### 5.3 跑一个完整一致性矩阵

先等待服务health ready，并从实际server_info或启动日志读取cache alignment。固定案例基准：2B544、9B528、27B800；运行边界如变化，驱动追加实际边界±1与2倍边界±1。

```bash
MODEL_NAME=Qwen3.5-9B MODEL_PATH=/models/Qwen3.5-9B MTP=2 \
CASE_ALIGNMENT=528 CACHE_ALIGNMENT=544 RESULT_DIR=/tmp/qwen9b-mtp2 \
BASE_URL=http://127.0.0.1:8000 python validate.py
python summarize.py /tmp/qwen9b-mtp2/final-validation.json
```

`CACHE_ALIGNMENT=544`是**本次9B MTP2实测值**，不是所有运行都能硬编码的常量。依次更换模型/MTP并单独保存结果，社区可复现9组；与1档位合并比较则需另存MTP1响应。每次需64输出tokens、greedy与temp0.8/top_p0.9/seed42；8或14输入，每输入每模式冷重复1、热重复1、混批2/4/8首尾各2，共128或224次比较。

### 5.4 独立比较跨档位结果

```bash
python summarize.py /tmp/qwen9b-mtp2/final-validation.json \
  /tmp/qwen9b-mtp3/final-validation.json /tmp/qwen9b-mtp4/final-validation.json \
  --output /tmp/qwen9b-cross.json
```

脚本根据实际输入token IDs配对冷缓存参考响应，输出greedy/sample分层的一致率、首个token分叉、完整logprobs相等和两侧文本。比较分叉后的logprob必须注明两侧上下文已不同；不能将其当成相同logits的数值误差。

### 5.5 真实top-p最小回放

```bash
VLLM_BATCH_INVARIANT=1 PYTHONPATH=/path/to/new-qwen-overlay \
  python replay_top_p.py --fixture /path/to/authorized/top-p-fixture.pt
```

需另行提供取得再分发授权的当时真实scaled logits，公开仓库不包含此张量；回放加载（纯tensor fixture，`weights_only=True`），构造B1/B8，分别调用原版adaptive helper与修复版；期望原版2个mask元素不同，修复版mask相等。首次线上分叉的raw logits/RNG trace证据在合并报告附录。该回放此前在GPU验证通过；此次打包只核对fixture及源码hash，没有再次申请GPU重跑。

## 6. 测量与回归要求

复现测试应先区分四种目标：

| 目标 | 当前验证结果 | 社区回归验收 |
|---|---|---|
| 固定MTP深度内cache/batch不变性 | MTP1三模型各128/128；MTP234九组1728/1728 | 文本、token IDs、完整返回logprobs、finish_reason零容差一致；cold/warm与B2/4/8首尾覆盖；记录实际重叠请求峰值 |
| 功能实际生效 | draft tokens=草稿轮数×MTP，accepted>0，prefix hits>0 | 不能只看启动参数；核对runtime、实际草稿数、prefix命中及FP8目标/草稿dtype |
| 吞吐/内存 | 只在MTP1旧阶段实测；MTP234未重测 | 吞吐关闭audit，预热后3轮中位数；共享/私有前缀同池同配置，唯一物理块并集计量 |
| 跨深度/相对MTP关闭等价 | 尚未通过；2B有logprob差，27B4档greedy分叉，所有跨档sample有变化 | 单独报告，不让固定档位100%掩盖此项 |

后续应补充的上游回归用例：gates的spec索引与非BI混合prefill/spec分支；FullAttention/Mamba联合命中长度单调性；请求移除/新增/压缩/交换时D2H快照所有权；BF16真实门控norm的不同M；top-p并列logit临界值B1/B8；BI关闭时原后端选择；eager之外的graph捕获单独研究。这些是**待新增上游测试计划**，不伪装为已执行单元测试。

## 7. 未解决问题与实际配置建议

1. **跨档位greedy数值/文本变化。** 2B2对3/4的三个输入token不变、选中logprob最大差0.0931459665；27B4对2/3的1600/1601/2442输入首分叉35/6/6。尚未做这组根因回放。下一步应只回放首分叉前相同上下文，比较cache命中长度及分段prefill形状，再核对主模型输入、投影、norm和FP8kernel；逐层找首差，不能直接归因为RNG，因为这些是greedy。
2. **跨档位采样同seed不同输出。** 不同提议/验证轮数可能改变随机数消耗，当前未验证分布是否偏。需要记录每次采样及拒绝采样的随机状态/offset，并区分分布等价与逐样本seed等价。现有top-p修复只解决固定深度的batch后端差异。
3. **MTP开关与长输出差异。** MTP1性能控制中的9B token相同57/78，27B30/78，生成256tokens；64token正式矩阵不能外推。需要在相同输入、同解码参数下增加MTP0控制及长输出回放。
4. **性能可移植性。** 单请求dispatch、固定norm布局、稳定排序的全局成本尚未做分项消融；MTP234无吞吐/内存收益数据；不据MTP1结果推荐4档获得更大加速。

若业务要求固定配置的批次稳定性，可以在相同环境内选择已测档位并固定MTP深度、checkpoint、tokenizer、CUDA工具链及所有开关。9B跨2/3/4的所测greedy完整响应都一致；27B可优先固定2或3，若使用4需接受已观察到的跨档位文本变化并做业务离线回放。2B重视完整数值等价时3和4在共享输入上相等，但不能声称与2等价。任何建议均限于本次矩阵。

## 8. 社区提交拆分

完整patch是本次**精确测试快照**。另提供六个拆分diff，按顺序应用可重建相同八文件：

| 文件 | 主题 | 提交说明 |
|---|---|---|
| `01-gdn-batch-invariance.patch` | base/metadata/Qwen GDN三文件 | 实验开关、逐请求fallback与gates索引当前合并在此。正式上游PR宜将无条件gates正确性修复与BI支持进一步拆开，移植后重验 |
| `02-hybrid-prefix-cache.patch` | coordinator | 可独立讨论hybrid命中长度单调性；说明对非BI路径也生效 |
| `03-accepted-count-snapshot.patch` | runner | 异步D2H缓冲区所有权及request mapping；新增/移除请求边界需回归 |
| `04-fixed-gated-norm-layout.patch` | FLA norm | BI固定布局，附真实BF16回放证据与性能成本边界 |
| `05-stable-top-p.patch` | sampler | BI统一后端及稳定tie顺序；附可接受外部授权fixture的回放脚本 |
| `90-cache-measurement.patch` | scheduler audit | 测量instrumentation，建议单独诊断/测试PR，不并入生产正确性PR |

拆分diff自身经过应用/hash验证，但**没有分别在GPU做独立消融**。多个依赖改动应先在分支完整应用再回归；不能据完整八文件通过认定每份单独均可生产使用。

`COMMUNITY_SUBMISSION.md`提供英文问题说明、期望/实际行为、测试矩阵、已知限制与建议PR题目。已创建独立issue（https://github.com/vllm-project/vllm/issues/64907），本仓库用于发布支持材料；尚未创建上游代码PR。没有凭空添加上游基线commit、权重下载身份或新的性能数字。

## 9. 此次交付校验与可审查性

此次整理验证了：完整patch反向重建8个原始hash；正向完整patch及拆分patch重建8个实际测试hash；安装器在匹配的最小源码树应用成功；所有交付Python能编译；便携入口dry-run参数完整；原始响应独立汇总；fixture及材料SHA256；报告内部相对链接可解析。记录见 `packaging-verification.json` 和 本地合并报告的交付校验记录。

本次新增的便携入口及汇总脚本属于复现材料适配，仅做本地配置与结果校验，未在GPU重新执行九组。2026-10-31的GPU原始实验结果与此次文档/打包校验分别记录，避免将打包成功写成新的模型实测。


## 10. 公开版本说明

最终八文件版本共11组1984/1984固定档位比较；历史2112次另含旧六文件2B MTP1的128次。混批为先预热缓存的请求，不是完整冷缓存混批矩阵。完整返回top-5对象相等不等于全词表logits相等。本次公开版剔除模型权重、张量fixture、原始响应及实验主机路径，保留数值汇总与每响应SHA256。这些摘要可重算所记录的相等关系，但不能替代持有checkpoint后的独立GPU验证。

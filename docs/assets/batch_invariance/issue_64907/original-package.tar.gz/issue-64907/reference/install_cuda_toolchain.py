import hashlib
import io
import json
import tarfile
import urllib.request
from pathlib import Path

base="https://developer.download.nvidia.com/compute/cuda/redist/"
manifest=json.load(urllib.request.urlopen(base+"redistrib_12.9.1.json",timeout=30))
root=Path("/tmp/qwen-cuda-12.9")
root.mkdir(exist_ok=True)
evidence={}
for component in ("cuda_nvcc","cuda_cudart","cuda_cccl"):
    row=manifest[component]["linux-x86_64"]
    data=urllib.request.urlopen(base+row["relative_path"],timeout=120).read()
    digest=hashlib.sha256(data).hexdigest()
    assert digest==row["sha256"]
    with tarfile.open(fileobj=io.BytesIO(data),mode="r:xz") as t:
        for member in t.getmembers():
            parts=Path(member.name).parts[1:]
            if not parts:
                continue
            member.name=str(Path(*parts))
            t.extract(member,root)
    evidence[component]={"version":manifest[component]["version"],"sha256":digest,"url":base+row["relative_path"]}
(root/"install-evidence.json").write_text(json.dumps(evidence,indent=2))
(root/"lib64").symlink_to("lib",target_is_directory=True)
print("CUDA_INSTALL_COMPLETE",evidence,flush=True)

"""Build an isolated vLLM package copy from the exact tested wheel sources."""
import argparse
import hashlib
import json
import py_compile
import shutil
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--source", required=True, type=Path, help="Original site-packages/vllm directory")
p.add_argument("--overlay", required=True, type=Path, help="New directory added to PYTHONPATH")
args = p.parse_args()
here = Path(__file__).resolve().parent
manifest = json.loads((here/"manifest.json").read_text())
target = args.overlay/"vllm"
if target.exists():
    raise SystemExit(f"Refusing to overwrite existing package: {target}")
for name, values in manifest["files"].items():
    digest = hashlib.sha256((args.source/name).read_bytes()).hexdigest()
    if digest != values["original_sha256"]:
        raise SystemExit(f"Source differs from tested vLLM wheel: {name} ({digest})")
shutil.copytree(args.source, target)
subprocess.run(["patch", "--batch", "--forward", "-p1", "-i",
                str(here/"vllm-0.24.0-cu129.patch")], cwd=target, check=True)
for name, values in manifest["files"].items():
    assert hashlib.sha256((target/name).read_bytes()).hexdigest() == values["patched_sha256"], name
    py_compile.compile(str(target/name), doraise=True)
print(json.dumps({"overlay": str(args.overlay.resolve()), "vllm": manifest["vllm"],
                  "verified_files": len(manifest["files"])}))

"""Portable launcher for the tested eager configuration; no system path edits."""
import argparse
import json
import os
import sys
from pathlib import Path

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--overlay", type=Path, required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--served-model-name", required=True)
    p.add_argument("--mtp", type=int, choices=(1, 2, 3, 4), default=1)
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()
    if not args.dry_run and not (args.overlay / "vllm").is_dir():
        p.error("Build the isolated overlay first")
    env = dict(os.environ)
    for key in ("QWEN35_CACHE_AUDIT_PATH", "QWEN35_STATE_DEBUG", "QWEN35_POOL_DEBUG",
                "QWEN_LARGER_TRACE", "QWEN_LARGER_RNG_TRACE"):
        env.pop(key, None)
    env.update(VLLM_BATCH_INVARIANT="1", QWEN35_BI_MTP_EXPERIMENT="1",
               VLLM_USE_FLASHINFER_SAMPLER="0", VLLM_SERVER_DEV_MODE="1")
    env["PYTHONPATH"] = str(args.overlay.resolve()) + os.pathsep + env.get("PYTHONPATH", "")
    command = [
        sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", args.model,
        "--served-model-name", args.served_model_name, "--host", "127.0.0.1",
        "--port", str(args.port), "--dtype", "bfloat16", "--max-model-len", "5120",
        "--max-num-seqs", "32", "--max-num-batched-tokens", "8192",
        "--gpu-memory-utilization", "0.80", "--language-model-only", "--enforce-eager",
        "--attention-config", '{"backend":"FLASH_ATTN","flash_attn_version":3}',
        "--mamba-cache-mode", "align", "--enable-prefix-caching",
        "--speculative-config", json.dumps({"method": "mtp", "num_speculative_tokens": args.mtp}),
    ]
    print(json.dumps({"command": command, "explicit_env": {
        k: env[k] for k in ("VLLM_BATCH_INVARIANT", "QWEN35_BI_MTP_EXPERIMENT",
                           "VLLM_USE_FLASHINFER_SAMPLER", "VLLM_SERVER_DEV_MODE", "PYTHONPATH")
    }}, indent=2), flush=True)
    if not args.dry_run:
        os.execve(sys.executable, command, env)

if __name__ == "__main__":
    main()

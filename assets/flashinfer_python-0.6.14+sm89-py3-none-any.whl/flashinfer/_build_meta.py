"""Build metadata for flashinfer package."""
__version__ = "0.6.14+sm89"
__git_version__ = "1227d9b42281a97bbbb04bbda7cda505a38ae247"

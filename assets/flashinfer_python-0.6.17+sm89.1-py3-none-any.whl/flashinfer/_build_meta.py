"""Build metadata for flashinfer package."""
__version__ = "0.6.17+sm89.1"
__git_commit__ = "unknown"

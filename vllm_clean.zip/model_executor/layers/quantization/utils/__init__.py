from .layer_utils import replace_parameter, update_tensor_inplace

__all__ = ['update_tensor_inplace', 'replace_parameter']

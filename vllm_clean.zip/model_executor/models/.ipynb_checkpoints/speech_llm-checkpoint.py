'''speechllm'''
from functools import lru_cache
from typing import List, Optional, Union, Dict, TypedDict, Any, Tuple, Literal
import numpy as np
import torch
import torch.nn as nn
from vllm.distributed import (get_pp_group, get_tensor_model_parallel_rank,
                              get_tensor_model_parallel_world_size)
import librosa
import os
import json
from datetime import datetime
from transformers import WhisperConfig, LlamaConfig, AutoFeatureExtractor, AutoTokenizer, GenerationConfig
from vllm.model_executor.layers.logits_processor import LogitsProcessor
from vllm.model_executor.layers.sampler import get_sampler, SamplerOutput
from vllm.model_executor.layers.vocab_parallel_embedding import ParallelLMHead, UnquantizedEmbeddingMethod
from vllm.model_executor.speechllm_model.models.Speech_Model import SpeechModel
from vllm.model_executor.models.llama import LlamaModel, LlamaForCausalLM
from vllm.model_executor.speechllm_model.models.audio_adaptor import AdaptorModel
from model.configuration.configuration_speechllm import AdaptorConfig
from vllm.inputs import INPUT_REGISTRY, InputContext
from vllm.multimodal import MultiModalKwargs, MULTIMODAL_REGISTRY
from vllm.sequence import (VLLM_INVALID_TOKEN_ID,
                           CompletionSequenceGroupOutput, Logprob,
                           PromptLogprobs, SampleLogprobs, SequenceOutput)

from vllm.model_executor.model_loader import get_model_architecture
from transformers.modeling_outputs import CausalLMOutputWithPast
from vllm.model_executor.layers.sampler import SamplingMetadata
from vllm.inputs import (INPUT_REGISTRY, DecoderOnlyInputs, DummyData,
                         InputContext, token_inputs)
from vllm.sequence import IntermediateTensors
from vllm.attention import AttentionMetadata
from vllm.sequence import SequenceData
from vllm.inputs import DummyData
from vllm.transformers_utils.tokenizer import get_tokenizer
from vllm.multimodal.utils import consecutive_placeholder_ranges
from vllm.config import ModelConfig, ParallelConfig, VllmConfig, CacheConfig, TokenizerPoolConfig, DeviceConfig
from vllm.model_executor.layers.quantization.base_config import QuantizationConfig
from vllm.model_executor.layers.quantization import get_quantization_config

from transformers import LlamaTokenizer
from vllm.worker.cache_engine import CacheEngine

import logging
logger = logging.getLogger("speechllm")

# === Constants === #
DEFAULT_SYSTEM_PROMPT = """A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions."""

DEFAULT_INSTRUCTION = ""  # 空字符串作为默认指令

LLM_TEMPLATE = "{llm_system_prompt} \n{user}: {instruction} \n{assistant}: "

# === Utils === #
def generate_llm_prompt(
    instruction: str,
    llm_system_prompt: str = """A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions.""",
    user: str = "Human",
    assistant: str = "Assistant"
) -> str:
    """生成新的prompt模板"""
    LLM_TEMPLATE = "{llm_system_prompt} \n{user}: {instruction} \n{assistant}: "
    return LLM_TEMPLATE.format_map({
        'llm_system_prompt': llm_system_prompt,
        'user': user,
        'assistant': assistant,
        'instruction': instruction
    })

# === Audio Input Type Definition === #
class SpeechLLMInputs(TypedDict):
    """Audio input structure for SpeechLLM
    Similar to Qwen2AudioInputs but adapted for SpeechLLM's requirements
    """
    input_features: torch.Tensor
    """Shape: `(num_audios, num_mel_bins, sequence_length)`"""
    
    feature_attention_mask: torch.Tensor
    """Shape: `(num_audios, sequence_length)`"""
    
    
# === Audio Feature Projector === #
class SpeechLLMMultiModalProjector(nn.Module):
    """Projects audio features to text model dimension
    Similar to Qwen2AudioMultiModalProjector but adapted for SpeechLLM
    """
    def __init__(self, audio_hidden_size: int, text_hidden_size: int):
        super().__init__()
        self.linear = nn.Linear(audio_hidden_size, text_hidden_size, bias=True)
        logger.info(f"Initialized projector with audio_size={audio_hidden_size}, text_size={text_hidden_size}")

    def forward(self, audio_features: torch.Tensor) -> torch.Tensor:
        logger.info(f"Projecting audio features of shape {audio_features.shape}")
        hidden_states = self.linear(audio_features)
        logger.info(f"Projected to shape {hidden_states.shape}")
        return hidden_states

def get_max_speechllm_audio_tokens(ctx: InputContext) -> int:
    max_position_embeddings = ctx.model_config.hf_config.text_config.max_position_embeddings
    output_lengths = (max_position_embeddings - 2) // 2 + 1
    return output_lengths

def dummy_data_for_speechllm(ctx: InputContext, seq_len: int, mm_counts: Dict[str, int]) -> DummyData:
    """Generate dummy data for SpeechLLM initialization"""
    # 获取真实的最大位置编码长度和profiling所需长度
    #max_position_embeddings = ctx.model_config.hf_config.text_config.max_position_embeddings
    #required_profiling_length = ctx.model_config.max_seq_len_to_capture
    max_position_embeddings = 2048
    required_profiling_length = 512
    profiling_seq_len = max(seq_len, required_profiling_length)
    
    num_audios = mm_counts["audio"]
    max_tokens_per_audio = min(
        get_max_speechllm_audio_tokens(ctx),
        (profiling_seq_len - 2) // 2  # 使用更大的序列长度限制
    )
    max_llm_audio_tokens = max_tokens_per_audio * num_audios
    
    if seq_len > max_position_embeddings:
        logger.warning(f"Requested sequence length {seq_len} exceeds maximum position embeddings {max_position_embeddings}")

    audio_token_index = ctx.model_config.hf_config.audio_token_index
    
    dummy_seqdata = SequenceData.from_prompt_token_counts(
        (audio_token_index, max_llm_audio_tokens),
        (0, seq_len - max_llm_audio_tokens)
    )
    
    dummy_audio_length = max_llm_audio_tokens * 2 * 2 * 160
    dummy_audio = np.full((dummy_audio_length, ), 0., dtype=np.float32)
    dummy_audios = [(dummy_audio, 16000)] * num_audios

    return DummyData(
        dummy_seqdata,
        {"audio": dummy_audios},
        {
            "audio": consecutive_placeholder_ranges(
                num_items=num_audios if num_audios ==2 else 2,
                item_size=max_tokens_per_audio
            )
        }
    )


def input_processor_for_speechllm(ctx: InputContext, inputs: DecoderOnlyInputs) -> DecoderOnlyInputs:
    audio_features = inputs.get("multi_modal_data", {}).get("audio", [])
    if not isinstance(audio_features, list) or len(audio_features) == 0:
        return inputs
    # === 以下为示例日志打印 ===
    prompt_str = inputs.get("prompt", "")
    # 1. 打印「原始 Prompt 字符串」
    logger.info("Final string for before tokenizer: %s", repr(prompt_str))

    # 2. 使用和推理中相同路径的tokenizer来做手动编码
    tokenizer = LlamaTokenizer.from_pretrained(
        "/home/jovyan/geo/infer_demo/meta-unicom-7b-multimodal.tokenizer",
        legacy=True  # 确保使用 legacy 模式
    )

    encoded = tokenizer(prompt_str, return_tensors="pt")  # 只做打印，不改inputs

    # 3. 打印分词结果的形状
    logger.info(f"Tokenized input shape: {encoded['input_ids'].shape}")

    # 4. 把「input_ids」和「attention_mask」整体也打印一下
    logger.info(f"Encoded tokens: {encoded}")

    # 5. decode回去，看看效果
    decoded_str = tokenizer.decode(encoded["input_ids"][0])
    logger.info("Decoded back: %s", repr(decoded_str))
    # === 日志打印结束 ===
    return inputs

def input_mapper_for_speechllm(
    ctx: InputContext,
    multi_modal_data: Union[np.ndarray, List[Tuple[np.ndarray, int]]],
) -> MultiModalKwargs:
    """处理音频特征并生成与模型输入兼容的格式。"""
    if not isinstance(multi_modal_data, list):
        multi_modal_data = [multi_modal_data]

    if len(multi_modal_data) == 0:
        return MultiModalKwargs()

    # 初始化音频特征提取器
    speech_model_path = "/home/jovyan/geo/infer_demo/whisper-large-v2"
    feature_extractor = AutoFeatureExtractor.from_pretrained(speech_model_path)

    # 重新采样并提取特征
    resampled_audios = [
        librosa.resample(audio, orig_sr=sr, target_sr=feature_extractor.sampling_rate)
        for audio, sr in multi_modal_data
    ]
    batch_data = feature_extractor(
        resampled_audios,
        sampling_rate=feature_extractor.sampling_rate,
        return_attention_mask=True,
        padding="max_length",
        return_tensors="pt"
    ).data

    # 验证特征
    input_features = batch_data["input_features"]
    feature_attention_mask = batch_data["attention_mask"]
    logger.info(f"Extracted input_features shape: {input_features.shape}")
    logger.info(f"Input features stats - min: {input_features.min().item():.4f}, max: {input_features.max().item():.4f}, mean: {input_features.mean().item():.4f}")
    return MultiModalKwargs({
        "input_features": input_features,
        "feature_attention_mask": feature_attention_mask
    })

# === 类装饰器 === #
@INPUT_REGISTRY.register_dummy_data(dummy_data_for_speechllm)
@INPUT_REGISTRY.register_input_processor(input_processor_for_speechllm)
@MULTIMODAL_REGISTRY.register_input_mapper("audio", input_mapper_for_speechllm)
@MULTIMODAL_REGISTRY.register_max_multimodal_tokens("audio", get_max_speechllm_audio_tokens)
class SpeechLLMForCausalLM(nn.Module):
    def __init__(
        self,
        torch_dtype=torch.bfloat16, 
        device_map="cuda:0",
        **kwargs
    ):
        super().__init__()
        self.device = torch.device(device_map)
        self.torch_dtype = torch_dtype
        self.model_paths = kwargs.get('model_paths', {})
        self.logger = logging.getLogger("speechllm")

        # 1. 创建vllm配置
        vllm_config = self.create_vllm_config(
            model_path=self.model_paths['base_model'],
            torch_dtype=self.torch_dtype,
            quantization=False
            
        )
        logger.info(f"VLLM 配置: {vllm_config.model_config.hf_config}")
        
        # 2. 检查并转换vllm_config的text_config，如果它是字典类型
        if isinstance(vllm_config.model_config.hf_config.text_config, dict):
            vllm_config.model_config.hf_config.text_config = LlamaConfig.from_dict(vllm_config.model_config.hf_config.text_config)
        
        # 2. 从配置字典创建配置对象
        text_config = vllm_config.model_config.hf_config.text_config
        speech_config = WhisperConfig(self.model_paths['speech_model'])
        # 4. 配置转换逻辑（确保text_config和speech_config是适当的对象类型）
        if isinstance(text_config, dict):
            text_config = LlamaConfig.from_dict(text_config)
        
        if isinstance(speech_config, dict):
            speech_config = WhisperConfig.from_dict(speech_config)
        # 3. 调整speech配置参数
        speech_config.max_position_embeddings = text_config.max_position_embeddings
        speech_config.vocab_size = text_config.vocab_size
        logger.info(f"Adjusted speech_config: {speech_config}")

        # 4. 初始化特征提取器
        self.speech_processor = AutoFeatureExtractor.from_pretrained(
            self.model_paths['speech_model'],
            config=speech_config,
            trust_remote_code=True
        )

        # 初始化文本模型
        self.text_model = LlamaForCausalLM(vllm_config=vllm_config).to(device=self.device, dtype=self.torch_dtype)

        # 加载文本模型权重
        self.load_text_model_weights(self.text_model, self.model_paths['base_model'], self.device)
        # 检查embedding权重
        embed_weight = self.text_model.model.embed_tokens.weight
       # 提取多模态相关的 token 索引
        self.audio_token_index = self.text_model.config.audio_token_index
        self.audio_start_token_index = self.text_model.config.audio_start_token_index
        self.audio_end_token_index = self.text_model.config.audio_end_token_index
        logger.info(f"Audio token indices: start={self.audio_start_token_index}, token={self.audio_token_index}, end={self.audio_end_token_index}")
        # 6. 初始化语音模型
        self.speech_model = SpeechModel.from_pretrain(
            self.model_paths['speech_model'],
            config=speech_config,  # 使用实例化后的配置
            torch_dtype=self.torch_dtype,
            device_map=device_map,
            use_pooling=True
        ).to(device=self.device, dtype=self.torch_dtype)
        # 打印模型权重信息
        logger.info(f"Speech model loaded successfully.")

           # Initialize multi-modal projector
        self.multimodal_projector = SpeechLLMMultiModalProjector(
            audio_hidden_size=speech_config.d_model,
            text_hidden_size=vllm_config.model_config.hf_config.hidden_size
        ).to(device=self.device, dtype=self.torch_dtype)
        # Initialize adaptor model
        adaptor_config = AdaptorConfig(
            hidden_size=1280,
            intermediate_size=5120,
            num_hidden_layers=2,
            num_attention_heads=20,
            hidden_act="gelu",
            layer_norm_eps=1e-5,
            attention_dropout=0.0,
            qkv_bias=True,
            projection_size=4096,
            only_use_projection=False
        )
        self.adaptor_model = AdaptorModel(adaptor_config).to(device=self.device, dtype=self.torch_dtype)
        self.adaptor_model.load_state_dict(
            torch.load(self.model_paths['adaptor_model'] + "/adapter_model.bin", weights_only=True)
        )
        logger.info("Adaptor model loaded successfully using from_pretrain.")
        # 加载适配器模型权重
        adaptor_weights_path = os.path.join(self.model_paths['adaptor_model'], "adapter_model.bin")
        adaptor_state_dict = torch.load(adaptor_weights_path, map_location=self.device)

        # 初始化logits处理器和采样器
        if get_pp_group().is_last_rank:
            self.unpadded_vocab_size = vllm_config.model_config.hf_config.vocab_size
            logit_scale = getattr(vllm_config.model_config.hf_config, "logit_scale", 1.0)
            self.logits_processor = LogitsProcessor(
                vocab_size=self.unpadded_vocab_size,
                org_vocab_size=self.unpadded_vocab_size,
                scale=logit_scale
            ).to(self.device)
            self.sampler = get_sampler()
        else:
            self.logits_processor = None
            self.sampler = None
            
        # Convert models to proper dtype
        self.text_model = self.text_model.to(torch.bfloat16)
        self.speech_model = self.speech_model.to(torch.bfloat16)
        self.adaptor_model = self.adaptor_model.to(torch.bfloat16)
        
        # Initialize state flags
        self.is_initialized = True
        self._first_inference = True
        
        self.logger.info("Model initialization completed successfully")
    
    @classmethod
    def supports_multimodal(cls) -> bool:
        return True
    
    def create_vllm_config(
        self,
        model_path: str,
        tokenizer_path: str = None,  # 可以添加一个可选参数
        torch_dtype: torch.dtype = torch.bfloat16,
        tensor_parallel_size: int = 1,
        pipeline_parallel_size: int = 1,
        quantization: bool = False,
        gpu_memory_utilization: float = 0.6,
        trust_remote_code: bool = True,
    ) -> VllmConfig:
        """创建完整的 VLLM 配置"""
        from transformers import LlamaConfig

        # 1. 获取 LlamaConfig
        base_config = LlamaConfig.from_pretrained(model_path)

        # 2. 创建模型基础配置
        model_config = ModelConfig(
            model=model_path,
            task="generate",
            tokenizer=model_path,  # 如果没有指定 tokenizer_path 就使用 model_path
            tokenizer_mode="auto",                       # 自动选择分词器模式
            trust_remote_code=True,         # 是否信任远程代码
            dtype=torch.bfloat16,       # 设置数据类型
            seed=0,                                     # 设置随机种子
            max_model_len=1024,                          # 使用默认序列长度
            quantization=None,
            max_seq_len_to_capture=512,   # CUDA 图序列捕获
            skip_tokenizer_init=False,                   # 不跳过分词器初始化
            hf_overrides={                              # 设置 HuggingFace 配置覆盖
                "architectures": base_config.architectures,
                "model_type": base_config.model_type,
                "vocab_size": 40079,
                "max_position_embeddings": 4096,
                "hidden_size": base_config.hidden_size,
                "num_hidden_layers": base_config.num_hidden_layers,
                "torch_dtype": torch.bfloat16,
            }
        )
        cache_config = CacheConfig(
            block_size=16,  # 设置合适的 block size
            gpu_memory_utilization=0.6,
            swap_space=4.0,  # 4GB CPU swap space
            cache_dtype="auto",  # 自动选择缓存数据类型
            sliding_window=None,  # 不使用滑动窗口
            enable_prefix_caching=True,  # 不启用前缀缓存
            cpu_offload_gb=0,  # 不使用 CPU offload
        )
        # 创建最小化的并行配置
        parallel_config = ParallelConfig(
            pipeline_parallel_size=1,  # 设置为1表示不使用流水线并行
            tensor_parallel_size=1,    # 设置为1表示不使用张量并行
            worker_use_ray=None,
            max_parallel_loading_workers=None,
            disable_custom_all_reduce=False
        )

        # 5. 设备配置
        device_config = DeviceConfig(device="cuda")

        return VllmConfig(
            model_config=model_config,
            parallel_config=parallel_config,
            device_config=device_config,
            cache_config = cache_config,
            quant_config=None,
        )
    @classmethod
    def from_speech_text_pretrained(cls, model_paths: dict, torch_dtype=torch.float16, device_map="cuda:0"):
        required_keys = ["speech_model", "base_model", "adaptor_model", "tokenizer"]
        missing_keys = [key for key in required_keys if key not in model_paths]
        if missing_keys:
            raise ValueError(f"Missing required keys in model_paths: {missing_keys}")

        return cls(torch_dtype=torch_dtype, device_map=device_map, model_paths=model_paths)
    
    def _validate_and_reshape_audio_tensor(
        self, tensor: Union[torch.Tensor, List[torch.Tensor]], name: str
    ) -> torch.Tensor:
        """验证并合并多模态音频张量"""
        if not isinstance(tensor, (torch.Tensor, list)):
            raise ValueError(f"Invalid type for {name}: {type(tensor)}. Expected torch.Tensor or List[torch.Tensor].")
        
        if isinstance(tensor, torch.Tensor):
            return tensor
        else:
            return torch.cat(tensor, dim=0)

    def _parse_and_validate_audio_input(self, **kwargs: object) -> Optional[SpeechLLMInputs]:
        input_features = kwargs.get("input_features")
        feature_attention_mask = kwargs.get("feature_attention_mask")

        if input_features is None or feature_attention_mask is None:
            # 只在第一次处理时记录警告
            if kwargs.get("audio_token_positions"):
                logger.warning("Audio features or attention mask is missing.")
            return None

        return SpeechLLMInputs(
            input_features=input_features,
            feature_attention_mask=feature_attention_mask
        )
    
    def _process_audio_input(self, audio_input: SpeechLLMInputs) -> torch.Tensor:
        """
        处理音频特征并将其转换为模型可用的维度。
        """
        input_features = audio_input["input_features"]  # Shape: [batch, num_audios, num_mel_bins, seq_len]
        feature_attention_mask = audio_input["feature_attention_mask"]

        batch_size, num_audios, num_mel_bins, seq_len = input_features.shape
        input_features = input_features.view(batch_size * num_audios, num_mel_bins, seq_len)  # Shape: [batch * num_audios, 80, 3000]
        feature_attention_mask = feature_attention_mask.view(batch_size * num_audios, seq_len)  # Shape: [batch * num_audios, 3000]
        '''
        audio_features = self.speech_model(
            input_features,
            audio_feat_lengths=feature_attention_mask.sum(dim=-1)  # 使用 attention_mask 计算长度
        ).last_hidden_state  # 输出形状: [batch * num_audios, reduced_seq_len, d_model]
        '''
        audio_features = self.speech_model(
            input_features  # 只传一个参数
        )

        audio_features = self.adaptor_model(audio_features)  # 输出形状: [batch * num_audios, reduced_seq_len, 1280]

        reduced_seq_len = audio_features.size(1)
        audio_features = audio_features.view(batch_size, num_audios, reduced_seq_len, -1)  # [batch, num_audios, reduced_seq_len, 1280]

        return audio_features

    
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_caches: List[torch.Tensor],
        attn_metadata: AttentionMetadata,
        **kwargs: object,
    ) -> torch.Tensor:
        audio_input = self._parse_and_validate_audio_input(**kwargs)

        if audio_input:
            inputs_embeds = self.text_model.model.embed_tokens(input_ids)
            audio_features = self._process_audio_input(audio_input)
            flattened_audio_features = audio_features.view(-1, audio_features.size(-1))

            # 找到 input_ids 中等于 audio_token_index 的位置
            mask = (input_ids == self.audio_token_index).view(-1)
            mask_indices = mask.nonzero(as_tuple=False).squeeze()
            mask_count = mask_indices.numel()

            # 如果音频特征数 != audio_token 个数
            cur_feat_count = flattened_audio_features.size(0)
            if mask_count != cur_feat_count:
                if mask_count > cur_feat_count:
                    # token 更多，就对特征进行padding
                    diff = mask_count - cur_feat_count
                    pad = torch.zeros(
                        (diff, flattened_audio_features.size(1)),
                        dtype=flattened_audio_features.dtype,
                        device=flattened_audio_features.device
                    )
                    flattened_audio_features = torch.cat([flattened_audio_features, pad], dim=0)
                else:
                    # 特征更多，就截断（保留前 mask_count 个）
                    flattened_audio_features = flattened_audio_features[:mask_count, :]

            # 将对齐后的特征写回 inputs_embeds
            if mask_count > 0:
                inputs_embeds.index_copy_(0, mask_indices, flattened_audio_features)
            # 打印前 10 个 inputs_embeds 的值（保留 6 位小数）
            inputs_embeds_sample = inputs_embeds.view(-1, inputs_embeds.size(-1))[:10]
            inputs_embeds_sample = inputs_embeds_sample.to(dtype=torch.float32).detach().cpu().numpy()
            inputs_embeds_sample = np.round(inputs_embeds_sample, decimals=6)
            logger.info(f"First 10 inputs_embeds values (rounded to 6 decimals): {inputs_embeds_sample}")
                
        else:
            inputs_embeds = self.text_model.model.embed_tokens(input_ids)

        return self.text_model(
            input_ids=None,
            positions=positions,
            kv_caches=kv_caches,
            attn_metadata=attn_metadata,
            inputs_embeds=inputs_embeds
        )
    
    def compute_logits(
        self,
        hidden_states: torch.Tensor,
        sampling_metadata: SamplingMetadata,
    ) -> Optional[torch.Tensor]:
        """直接使用LlamaForCausalLM的compute_logits"""
        return self.text_model.compute_logits(hidden_states, sampling_metadata)
    '''
    def compute_logits(
        self,
        hidden_states: torch.Tensor,
        sampling_metadata: SamplingMetadata,
    ) -> Optional[torch.Tensor]:
        logits = self.text_model.compute_logits(hidden_states, sampling_metadata)

        # 将 logits 转换为 Float32 类型
        logits_float32 = logits.to(dtype=torch.float32).detach().cpu().numpy()

        # 检查 logits 的维度
        if logits_float32.ndim == 3:
            # 3D 张量，按 token 遍历
            for i in range(min(10, logits_float32.shape[1])):  # 遍历前 10 个 token
                token_logits = np.round(logits_float32[:, i, :], decimals=6)  # 提取第 i 个 token 的 logits
                logger.info(f"Logits for token {i}: {token_logits}")
        elif logits_float32.ndim == 2:
            # 2D 张量，直接打印前 10 行
            logits_sample = np.round(logits_float32, decimals=6)
            logger.info(f"First 10 logits (rounded to 6 decimals): {logits_sample}")
            logger.info(f"logits shape: {logits_float32.shape}")
        else:
            logger.warning(f"Unexpected logits shape: {logits_float32.shape}")

        return logits
        '''


    def sample(
        self,
        logits: torch.Tensor,
        sampling_metadata: SamplingMetadata,
    ) -> Optional[SamplerOutput]:
        """直接使用LlamaForCausalLM的sample"""
        return self.text_model.sample(logits, sampling_metadata)

    def load_text_model_weights(self, text_model, weights_path, device):
        """加载文本模型的权重"""
        logger.info(f"Loading weights from {weights_path}")

        state_dict = {}
        index_path = os.path.join(weights_path, "pytorch_model.bin.index.json")
        if os.path.exists(index_path):
            logger.info("Found sharded model weights")
            with open(index_path, 'r') as f:
                index = json.load(f)

            num_shards = 2
            for i in range(1, num_shards + 1):
                shard_path = os.path.join(weights_path, f"pytorch_model-{i:05d}-of-{num_shards:05d}.bin")
                logger.info(f"Loading shard {i} from {shard_path}")
                shard_state = torch.load(shard_path, map_location=device)
                state_dict.update(shard_state)

        elif os.path.exists(os.path.join(weights_path, "model.safetensors")):
            from safetensors.torch import load_file
            logger.info("Loading weights from safetensors file")
            state_dict = load_file(os.path.join(weights_path, "model.safetensors"))
        elif os.path.exists(os.path.join(weights_path, "pytorch_model.bin")):
            logger.info("Loading weights from pytorch bin file")
            state_dict = torch.load(os.path.join(weights_path, "pytorch_model.bin"))

        if not state_dict:
            raise ValueError(
                f"No weights file found in {weights_path}. "
                "Expected either sharded model, safetensors or pytorch_model.bin"
            )

        weights = state_dict.items()
        logger.info("Successfully loaded weights, applying to model...")
        text_model.load_weights(weights)
        logger.info("Text model weights loaded successfully.")

'''This file is Speech_llm.py 原始的模型构建文件，用于多模态模型的集成'''
from typing import Optional, List, Union
import os
import torch
import logging
from torch import nn
from transformers.modeling_utils import PreTrainedModel
from transformers import LlamaForCausalLM, LlamaConfig,AutoConfig
from transformers import AutoFeatureExtractor, WhisperConfig, WhisperModel
#from transformers.models.clip.modeling_clip import CLIPVisionConfig, CLIPVisionModel
#from huggingface_hub import hf_hub_download
from .configuration.configuration_speechllm import SpeechLlmConfig

import librosa
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
from model.models.Speech_Model import SpeechModel
from model.models.Text_Model import TextModel
# from model.models.Adaptor_Model import AdaptorModel
from model.models.audio_adaptor import AdaptorModel
from model.configuration.configuration_speechllm import AdaptorConfig
def extend_position_embedding(state_dict, patch_size, after):
    """
    modify state_dict in-place for longer position embeddings
    """
    keys = {}
    for k, v in state_dict.items():
        if k.endswith('speech_model.embeddings.position_embedding.weight'):
            assert k not in keys
            keys['pe'] = (k, v)
        if k.endswith('speech_model.embeddings.position_ids'):
            assert k not in keys
            keys['pi'] = (k, v)

    pe_weight = keys['pe'][1]
    position_length_before = pe_weight.shape[0]
    embed_dim = pe_weight.shape[1]
    grid_before = position_length_before - 1
    position_length_after = (after // patch_size) ** 2 + 1
    grid_after = position_length_after - 1

    new_pe_weight = pe_weight[1:].reshape((grid_before, grid_before, -1))
    new_pe_weight = torch.nn.functional.interpolate(
        new_pe_weight.permute(2, 0, 1).unsqueeze(0),
        size=(grid_after, grid_after), mode='bicubic')
    new_pe_weight = new_pe_weight.squeeze(0).permute(1, 2, 0).reshape(grid_after * grid_after, -1)
    new_pe_weight = torch.cat((pe_weight[0:1], new_pe_weight), dim=0)
    assert new_pe_weight.shape == (grid_after * grid_after + 1, embed_dim)

    state_dict[keys['pe'][0]] = new_pe_weight
    state_dict[keys['pi'][0]] = torch.arange(grid_after * grid_after + 1).unsqueeze(0)
    return state_dict


class SpeechLlmPreTrainedModel(PreTrainedModel):
    """
    An abstract class to handle weights initialization.
    """

    config_class = SpeechLlmConfig
    base_model_prefix = "sppechllm"
    supports_gradient_checkpointing = True

    def _init_weights(self, module):
        """Initialize the weights"""
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)


class SpeechLlmModel(SpeechLlmPreTrainedModel):
    def __init__(
            self,
            config: SpeechLlmConfig = None,
            speech_model: Optional[PreTrainedModel] = None,
            text_model: Optional[PreTrainedModel] = None,
            adaptor_model=None,
            torch_dtype=torch.float16,
            device=None
    ):
        if isinstance(config.text_config, dict):
            config.text_config = LlamaConfig(**config.text_config)
        if isinstance(config.speech_config, dict):
            config.speech_config = WhisperConfig(**config.speech_config)
        super().__init__(config)
        if speech_model is None:
            if config.speech_config is not None:
                speech_config = WhisperConfig(**config.speech_config)
                speech_model = WhisperModel(speech_config)

        if text_model is None:
            if config.text_config is not None:
                text_config = LlamaConfig(**config.text_config)
                text_model = LlamaForCausalLM(text_config)

        self.speech_model = speech_model
        self.text_model = text_model
        self.torch_dtype = torch_dtype
        self.adaptor_model=adaptor_model

        if device:
            self.adaptor_model = self.adaptor_model.to(device)
        self.speech_at_head = False

    def gradient_checkpointing_enable(self):
        self.text_model.gradient_checkpointing_enable()

    def resize_token_embeddings(self, new_num_tokens):
        return self.text_model.resize_token_embeddings(new_num_tokens)


    @classmethod
    def from_speech_text_pretrained(
            cls,
            speech_model_name_or_path: str = None,
            text_model_name_or_path: str = None,
            adaptor_model_name_or_path: str = None,
            speechllm_config: Union[str, SpeechLlmConfig] = None,
            torch_dtype=torch.float16,
            default_device=None,
            device_map=None,
            load_in_8bit=False,
            **kwargs,
    ) -> PreTrainedModel:

        training_mode = kwargs.get('training_mode', None)
        new_tokenizer_size = kwargs.get('new_tokenizer_size', None)
        use_speech_model_pooling = kwargs.get('use_speech_model_pooling', False)
        logger.info(f"use_speech_model_pooling: {use_speech_model_pooling}")

        if isinstance(speechllm_config, str):
            speechllm_config = SpeechLlmConfig.from_pretrained(speechllm_config)

        kwargs_speech = {
            argument[len("speech_"):]: value for argument, value in kwargs.items() if argument.startswith("speech_")
        }

        kwargs_text = {
            argument[len("text_"):]: value for argument, value in kwargs.items() if argument.startswith("text_")
        }

        # remove speech, text kwargs from kwargs
        for key in kwargs_speech.keys():
            del kwargs["speech_" + key]
        for key in kwargs_text.keys():
            del kwargs["text_" + key]

        # Load and initialize the speech and text model
        speech_model = kwargs_speech.pop("model", None)
        if speech_model is None:
            if speech_model_name_or_path is None:
                raise ValueError(
                    "If `speech_model` is not defined as an argument, a `speech_model_name_or_path` has to be defined"
                )

            if ("config" not in kwargs_speech) or ("config" in kwargs_speech and kwargs_speech["config"] is None):
                speech_config = AutoConfig.from_pretrained(speech_model_name_or_path)

            else:
                # "speech_config" for function params
                speech_config = kwargs_speech["config"]
            speech_model=SpeechModel(speech_model_name_or_path=speech_model_name_or_path,
                                                        torch_dtype=torch_dtype,
                                                        device_map=device_map,
                                                        config=speech_config,
                                                        use_pooling=use_speech_model_pooling)

        text_model = kwargs_text.pop("model", None)
        if text_model is None:
            if text_model_name_or_path is None:
                raise ValueError(
                    "If `text_model` is not defined as an argument, a `text_model_name_or_path` has to be defined"
                )

            if ("config" not in kwargs_text) or ("config" in kwargs_text and kwargs_text["config"] is None):
                text_config = AutoConfig.from_pretrained(text_model_name_or_path)
            else:
                # "text_config" for function params
                text_config = kwargs_text["config"]
            text_model = TextModel(text_model_name_or_path=text_model_name_or_path,
                                                          torch_dtype=torch_dtype,
                                                          low_cpu_mem_usage=True,
                                                          device_map=device_map,
                                                          load_in_8bit=load_in_8bit,
                                                          config=text_config)

        #speechllm_config.text_config = text_config.to_dict()
        #speechllm_config.speech_config = speech_config.to_dict()
        speechllm_config.text_config = text_config
        speechllm_config.speech_config = speech_config
        #speech_embed_dim = speechllm_config.speech_config['d_model']
        # 获取speech_embed_dim
        if isinstance(speechllm_config.speech_config, dict):
            speech_embed_dim = speechllm_config.speech_config['d_model']
        else:
            speech_embed_dim = speechllm_config.speech_config.d_model
        # 获取text_embed_dim
        if isinstance(speechllm_config.text_config, dict):
            text_embed_dim = speechllm_config.text_config['hidden_size']
        else:
            text_embed_dim = speechllm_config.text_config.hidden_size
        adaptor_config = AdaptorConfig(hidden_size=speech_embed_dim,
                              output_size=text_embed_dim)

        if adaptor_model_name_or_path is not None:
            logger.info(f"load adaptor model from path: {adaptor_model_name_or_path}")
            adaptor_model = AdaptorModel.from_pretrain(load_directory=adaptor_model_name_or_path,
                                                       speech_embed_dim=speech_embed_dim,
                                                       config=adaptor_config,
                                                       torch_dtype=torch_dtype,
                                                       device_map=device_map)
        else:
            adaptor_model = AdaptorModel(adaptor_config)
            # adaptor_model._init_weights(speechllm_config.initializer_range)
            adaptor_model.to(torch_dtype)

        # init model
        model = cls(config=speechllm_config,
                    speech_model=speech_model,
                    text_model=text_model,
                    adaptor_model=adaptor_model,
                    torch_dtype=torch_dtype,
                    device=default_device)

        # resize new tokenizer embeding
        ori_model_vocab_size = model.get_input_embeddings().weight.shape[0]
        logger.info(f"Model vocab size: {ori_model_vocab_size}")
        logger.info(f"len(tokenizer):{new_tokenizer_size}")

        if new_tokenizer_size is not None and ori_model_vocab_size != new_tokenizer_size:
            logger.info(f"Resize model vocab size to {new_tokenizer_size}")
            model.resize_token_embeddings(new_tokenizer_size)

        model.set_training_mode(training_mode)
        if model.fixed_ori_token_embedding:
            model.set_ori_token_lm_head(ori_model_vocab_size)
        else:
            model.ori_model_vocab_size = ori_model_vocab_size
        return model


    def set_ori_token_lm_head(self, ori_model_vocab_size):
        self.ori_model_vocab_size = ori_model_vocab_size
        self.ori_token_lm_head = self.text_model.text_model.lm_head.weight.data[0:ori_model_vocab_size].clone()


    def copy_lm_head(self):
        if self.fixed_ori_token_embedding:
            self.text_model.text_model.lm_head.weight.data[0 : self.ori_model_vocab_size].copy_(self.ori_token_lm_head)


    def set_training_mode(self, training_mode):
        logger.info(f"training_mode: {training_mode}")
        self.requires_grad_(False)
        self.fixed_ori_token_embedding = False
        if training_mode is not None:
            if training_mode in ["sft_speech_model", "sft_speech_adaptor_model", "sft_all"]:
                logger.info("Set speech encoder grad True.")
                self.speech_model.requires_grad_(True)
                for name, parameters in self.speech_model.named_parameters():
                    if "decoder" in name:
                        parameters.requires_grad = False
            if training_mode in ["sft_adaptor_model", "sft_speech_adaptor_model", "sft_all", "sft_text_adaptor_model"]:
                logger.info("Set adaptor grad True.")
                self.adaptor_model.requires_grad_(True)
            if training_mode in ["sft_text_model", "sft_all", "sft_text_adaptor_model"]:
                logger.info("Set text model grad True.")
                self.text_model.requires_grad_(True)
            else:
                logger.info("Set embed_tokens and lm head grad True.")
                self.fixed_ori_token_embedding = True
                text_model_trainable_keys = ["embed_tokens", "lm_head"]
                for name, parameters in self.text_model.named_parameters():
                    hit = any([k in name for k in text_model_trainable_keys])
                    parameters.requires_grad = hit

        return True


    def concat_speech_text(
                        self,
                        input_ids,
                        fbanks,
                        encoded_dim,
                        attention_mask,
                        labels
    ):

        input_embeds = self.get_input_embeddings()(input_ids)

        if self.fixed_ori_token_embedding:
            for i in range(input_embeds.size(0)):
                cur_input_ids = input_ids[i]
                cur_input_embed = input_embeds[i]
                ori_token_idx = cur_input_ids.lt(self.ori_model_vocab_size)
                input_embeds[i][ori_token_idx] = cur_input_embed[ori_token_idx].detach()

        if fbanks is not None:
            # Vision Features
            # vision_outputs = self.vision_model(pixel_values=pixel_values)

            fbanks = fbanks.to(dtype=self.torch_dtype)
            speech_embeds = self.speech_model(fbanks)

            speech_embeds = self.adaptor_model(speech_embeds)

            if self.speech_at_head:
                multimodal_embeds = torch.concat([input_embeds[:, :2], speech_embeds, input_embeds[:, 2:]], dim=1)
            else:
                new_input_embeds = []
                for cur_input_ids, cur_input_embeds, cur_speech_embeds, cur_encoded_dim in zip(input_ids, input_embeds,
                                                                                              speech_embeds,
                                                                                              encoded_dim):
                    # num_patch = cur_image_embeds.shape[0]
                    num_patch = cur_encoded_dim.item()
                    cur_speech_embeds = cur_speech_embeds[:num_patch, :]
                    speech_start_token_pos = torch.where(cur_input_ids == self.tokenizer.speech_start_token_id)[0]
                    if len(speech_start_token_pos) == 0 or not self.tokenizer.speech_token_id in cur_input_ids:
                        new_input_embeds.append(cur_input_embeds)
                        continue
                    if cur_input_ids[speech_start_token_pos + num_patch + 1] != self.tokenizer.speech_end_token_id:
                        print(cur_input_ids)
                        raise ValueError(
                            f"Num of patch ({num_patch}) is not equal to the length of pre-filled speech patch tokens.")
                    cur_new_input_embeds = torch.cat([cur_input_embeds[:speech_start_token_pos + 1], cur_speech_embeds,
                                                      cur_input_embeds[speech_start_token_pos + num_patch + 1:]], dim=0)
                    if (cur_new_input_embeds.shape[0] != cur_input_ids.shape[0]):
                        raise ValueError(
                            f"cur_input_ids[{cur_input_ids.shape}] cur_new_input_embeds[{cur_new_input_embeds.shape}] cur_speech_embeds[{cur_speech_embeds.shape}] num_patch[{num_patch}].")
                    new_input_embeds.append(cur_new_input_embeds)
                multimodal_embeds = torch.stack(new_input_embeds, dim=0)

            if attention_mask is not None:
                if self.speech_at_head:
                    speech_mask = torch.ones(speech_embeds.shape[:2], dtype=input_ids.dtype, device=input_ids.device)
                    multimodal_mask = torch.concat([speech_mask, attention_mask], dim=1)
                else:
                    multimodal_mask = attention_mask

        else:
            multimodal_embeds = input_embeds
            multimodal_mask = attention_mask
        if(labels is not None):
            if 'llama' in self.text_model.__module__:  # decoder text model, add -100 as labels for speech patchs
                if self.speech_at_head:
                    labels = torch.concat([labels[:, [0]], torch.ones(speech_embeds.shape[:2], dtype=labels.dtype,
                                                                          device=labels.device) * -100, labels[:, 1:]],
                                              dim=1)
        return multimodal_embeds,multimodal_mask,labels
    def forward(
            self,
            input_ids: Optional[torch.LongTensor] = None,
            fbanks: Optional[torch.FloatTensor] = None,
            encoded_dim: Optional[torch.LongTensor] = None,
            attention_mask: Optional[torch.Tensor] = None,
            position_ids: Optional[torch.LongTensor] = None,
            past_key_values: Optional[List[torch.FloatTensor]] = None,
            labels: Optional[torch.LongTensor] = None,
            use_cache: Optional[bool] = None,
            return_loss: Optional[bool] = None,
            return_dict: Optional[bool] = None,
            **kwargs,
    ):
        '''
        attention_mask: mask for the text
        '''

        multimodal_embeds,multimodal_mask,labels=self.concat_speech_text(input_ids,fbanks,encoded_dim,attention_mask,labels)

        outputs = self.text_model(
            inputs_embeds=multimodal_embeds,
            attention_mask=multimodal_mask,
            past_key_values=past_key_values,
            labels=labels,
            use_cache=use_cache,
            return_dict=return_dict
        )

        return outputs


    @torch.no_grad()
    def generate(
            self,
            input_ids=None,
            fbanks=None,
            encoded_dim=None,
            attention_mask=None,
            generation_config=None,
            logits_processor=None,
            stopping_criteria=None,
            prefix_allowed_tokens_fn=None,
            synced_gpus=False,
            **kwargs,
    ):

        labels=None
        multimodal_embeds,multimodal_mask,labels=self.concat_speech_text(input_ids,fbanks,encoded_dim,attention_mask,labels)

        outputs = self.text_model.generate(
            inputs_embeds=multimodal_embeds,
            attention_mask=multimodal_mask,
            generation_config=generation_config,
            logits_processor=logits_processor,
            stopping_criteria=stopping_criteria,
            prefix_allowed_tokens_fn=prefix_allowed_tokens_fn,
            synced_gpus=synced_gpus,
            **kwargs
        )
        return outputs

    def get_input_embeddings(self):
        return self.text_model.get_input_embeddings()

    def set_input_embeddings(self, new_embeddings):
        self.text_model.set_input_embeddings(new_embeddings)

    def get_output_embeddings(self):
        return self.text_model.get_output_embeddings()

    def set_output_embeddings(self, new_embeddings):
        self.text_model.set_output_embeddings(new_embeddings)


def build_multimodal_models(
        tokenizer=None,
        text_config=None,
        text_model_name_or_path=None,
        speech_model_name_or_path=None,
        adaptor_model_name_or_path=None,
        lora_model=None,
        torch_dtype=torch.float16,
        default_device=None,
        device_map=None,
        load_in_8bit=False,
        training_mode=None,
        use_speech_model_pooling=False
):

    # special tokenizer for audio
    # special_token_dict = {'additional_special_tokens': ['<|audio_start|>','<|audio_end|>','<pad>','<|audio_token|>']}
    tokenizer.speech_start_token = '<|audio_start|>'
    tokenizer.speech_start_token_id = tokenizer.convert_tokens_to_ids(tokenizer.speech_start_token)
    tokenizer.speech_end_token = '<|audio_end|>'
    tokenizer.speech_end_token_id = tokenizer.convert_tokens_to_ids(tokenizer.speech_end_token)
    tokenizer.speech_token = '<|audio_token|>'
    tokenizer.speech_token_id = tokenizer.convert_tokens_to_ids(tokenizer.speech_token)

    new_tokenizer_size = len(tokenizer)

    assert (text_model_name_or_path is not None) and (speech_model_name_or_path is not None)
    logger.info("Init Speech_Llm model with pretrained text/speech encoders")
    if (lora_model is None):
        speechllm_config = SpeechLlmConfig()
    else:
        speechllm_config = SpeechLlmConfig.from_pretrained(lora_model)
    if isinstance(text_config, dict):
        text_config = LlamaConfig(**text_config)
    model = SpeechLlmModel.from_speech_text_pretrained(
        speech_model_name_or_path=speech_model_name_or_path,
        text_config=text_config,
        text_model_name_or_path=text_model_name_or_path,
        speechllm_config=speechllm_config,
        adaptor_model_name_or_path=adaptor_model_name_or_path,
        torch_dtype=torch_dtype,
        default_device=default_device,
        device_map=device_map,
        load_in_8bit=load_in_8bit,
        training_mode=training_mode,
        new_tokenizer_size=new_tokenizer_size,
        use_speech_model_pooling=use_speech_model_pooling
    )

    speech_processor = AutoFeatureExtractor.from_pretrained(speech_model_name_or_path)
    model.tokenizer = tokenizer
    model.speech_processor = speech_processor
    model.speech_at_head = False
    print("\n=== Model Build Debug Info ===")
    print(f"Model input embeddings shape: {model.get_input_embeddings().weight.shape}")
    
    # 检查关键组件
    print("\nModel components:")
    print(f"text_model exists: {hasattr(model, 'text_model')}")
    print(f"speech_model exists: {hasattr(model, 'speech_model')}")
    print(f"adaptor_model exists: {hasattr(model, 'adaptor_model')}")

    return model, speech_processor


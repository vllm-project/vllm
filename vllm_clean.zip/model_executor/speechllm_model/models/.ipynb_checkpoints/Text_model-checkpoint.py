"""TextModel implementation with proper caching mechanism for vLLM"""
from typing import Optional, Dict, Union, Any, List, Tuple, Iterable
import os
import torch
from torch import nn
from transformers import PreTrainedModel, LlamaConfig, WhisperConfig
from vllm.config import CacheConfig, VllmConfig
from vllm.distributed import (
    get_pp_group, 
    get_tensor_model_parallel_rank,
    get_tensor_model_parallel_world_size
)
from vllm.model_executor.models.llama import (
    LlamaModel, 
    LlamaForCausalLM,
    LlamaAttention,
    LlamaDecoderLayer
)
from vllm.model_executor.layers.quantization import QuantizationConfig
from vllm.sequence import IntermediateTensors, PoolerOutput
from vllm.model_executor.layers.logits_processor import LogitsProcessor
from vllm.model_executor.layers.sampler import get_sampler, SamplerOutput
from vllm.model_executor.layers.pooler import Pooler, PoolingType
from vllm.model_executor.layers.vocab_parallel_embedding import (
    DEFAULT_VOCAB_PADDING_SIZE,
    ParallelLMHead,
    VocabParallelEmbedding
)
from vllm.model_executor.layers.sampler import SamplingMetadata
from vllm.attention import Attention, AttentionMetadata
from vllm.model_executor.layers.layernorm import RMSNorm
from vllm.model_executor.models.utils import (
    AutoWeightsLoader,
    PPMissingLayer,
    is_pp_missing_parameter,
    make_empty_intermediate_tensors_factory,
    make_layers,
    maybe_prefix
)
from vllm.attention.backends.flash_attn import FlashAttentionBackend
import logging
logger = logging.getLogger("speechllm")

class TextModel(PreTrainedModel):
    """分布式并行的LLaMA模型,适配vLLM并实现正确的缓存机制"""
    
    def __init__(
        self,
        text_model_name_or_path: str,
        torch_dtype: torch.dtype = torch.bfloat16,
        low_cpu_mem_usage: bool = True,
        device_map: Union[str, Dict[str, Union[int, str, torch.device]]] = "auto",
        load_in_8bit: bool = False,
        vllm_config: Optional[VllmConfig] = None,
    ):
        text_config = vllm_config.model_config.hf_config
        
            # 转换text_config
        if hasattr(text_config, "text_config") and isinstance(text_config.text_config, dict):
            text_config.text_config = LlamaConfig.from_dict(text_config.text_config)

        # 转换speech_config
        if hasattr(text_config, "speech_config") and isinstance(text_config.speech_config, dict):
            text_config.speech_config = WhisperConfig.from_dict(text_config.speech_config)
        # 确保主配置正确
        if isinstance(text_config, dict) and 'model_type' in text_config:
            if text_config['model_type'].lower() == 'llama':
                text_config = LlamaConfig(**text_config)
            else:
                raise ValueError(f"不支持的model_type: {text_config['model_type']}")
        else:
            text_config = text_config
                
        super().__init__(text_config)
        self.config = text_config
        self.torch_dtype = torch_dtype
        self.padding_idx = text_config.pad_token_id
        self.vocab_size = text_config.vocab_size

        # 解析 device_map
        device = (
            torch.device("cuda") if device_map == "auto" else torch.device(device_map)
            if isinstance(device_map, str)
            else torch.device("cuda")
        )
        self.register_buffer("_device_buffer", torch.zeros(1, device=device))

        # 基础模型初始化
        self.model = LlamaModel(
            vllm_config=vllm_config,
        ).to(device=device, dtype=self.torch_dtype)

        # 获取pipeline并行组
        pp_group = get_pp_group()

        # 设置layer范围
        self.start_layer = 0
        self.end_layer = text_config.num_hidden_layers
        self.layers = nn.ModuleList([
            LlamaDecoderLayer(
                config=text_config,
                cache_config=vllm_config.cache_config,
                quant_config=vllm_config.quant_config,
                prefix=f"layers.{i}"
            ).to(device=self.device, dtype=self.torch_dtype)
            for i in range(self.start_layer, self.end_layer)
        ])
        # 在这里检查QKV权重，此时layers已经初始化完成
        logger.info("Checking QKV weights after layer initialization:")
        for i, layer in enumerate(self.layers):
            if hasattr(layer, 'self_attn') and hasattr(layer.self_attn, 'qkv_proj'):
                qkv_weight = layer.self_attn.qkv_proj.weight
                logger.info(f"Layer {i} QKV proj weight stats:")
                logger.info(f"- Mean: {qkv_weight.mean():.6f}")
                logger.info(f"- Std: {qkv_weight.std():.6f}")
                logger.info(f"- Shape: {qkv_weight.shape}")
        
        
        # 初始化组件，使用_device_buffer.device替代之前的self.device
        self.unpadded_vocab_size = text_config.vocab_size
        self.padded_vocab_size = ((self.unpadded_vocab_size + DEFAULT_VOCAB_PADDING_SIZE - 1) 
                         // DEFAULT_VOCAB_PADDING_SIZE) * DEFAULT_VOCAB_PADDING_SIZE
        logger.info(f"Initializing LM head with vocab_size={self.unpadded_vocab_size}, hidden_size={text_config.hidden_size}")
        # 添加详细的词表大小日志
        logger.info(f"Vocabulary size details:")
        logger.info(f"- Original vocab size: {text_config.vocab_size}")
        logger.info(f"- Unpadded vocab size: {self.unpadded_vocab_size}")
        logger.info(f"- Padded vocab size: {self.padded_vocab_size}")
        logger.info(f"- Padding size: {DEFAULT_VOCAB_PADDING_SIZE}")
        if pp_group.is_first_rank:
            logger.info("Creating VocabParallelEmbedding")
            self.embed_tokens = VocabParallelEmbedding(
                self.padded_vocab_size,
                text_config.hidden_size,
                org_num_embeddings=self.unpadded_vocab_size,
                quant_config=vllm_config.quant_config,
                prefix="embed_tokens"
            ).to(device=self.device, dtype=self.torch_dtype)
            logger.info(f"Embedding shape after creation: {self.embed_tokens.weight.shape}")
        else:
            self.embed_tokens = PPMissingLayer()
            
        if pp_group.is_last_rank:
            logger.info("Creating ParallelLMHead (pp_group.is_last_rank=True)")
            self.lm_head = ParallelLMHead(
                self.padded_vocab_size,
                text_config.hidden_size, 
                org_num_embeddings=text_config.vocab_size,
                padding_size=DEFAULT_VOCAB_PADDING_SIZE,  # 默认64
                quant_config=vllm_config.quant_config,
                prefix="lm_head"   # 这个前缀很重要,用于加载权重
            ).to(device=self.device, dtype=self.torch_dtype)
            self.lm_head_tied = False
            logger.info(f"LM head created with shape: {self.lm_head.weight.shape}")
        else:
            logger.info("Creating PPMissingLayer for LM head (pp_group.is_last_rank=False)")
            self.lm_head = PPMissingLayer()
            
        # 初始化Transformer层
        self.layers = nn.ModuleList([
            LlamaDecoderLayer(
                config=text_config,
                cache_config=vllm_config.cache_config,
                quant_config=vllm_config.quant_config,
                prefix=f"layers.{i}"
            ).to(device=self.device, dtype=self.torch_dtype)
            for i in range(self.start_layer, self.end_layer)
        ])

        # 其他组件初始化
        if pp_group.is_last_rank:
            self.norm = RMSNorm(text_config.hidden_size, eps=text_config.rms_norm_eps).to(device=self.device, dtype=self.torch_dtype)
        else:
            self.norm = PPMissingLayer()

        self.sampler = get_sampler()
        self.logits_processor = LogitsProcessor(vocab_size=self.unpadded_vocab_size)

        # 缓存配置
        self.max_position_embeddings = getattr(text_config, "max_position_embeddings", 2048)
        self.hidden_size = text_config.hidden_size
        self.num_attention_heads = text_config.num_attention_heads
        self.head_dim = self.hidden_size // self.num_attention_heads
        self.norm.weight.data = self.norm.weight.data.to(self.torch_dtype)
        # 检查head_size是否支持Flash Attention
        supported_sizes = FlashAttentionBackend.get_supported_head_sizes()
        if self.head_dim not in supported_sizes:
            logger.warning(f"head_size {self.head_dim} 不被Flash Attention支持")

        # 创建空张量工厂
        self.make_empty_intermediate_tensors = make_empty_intermediate_tensors_factory(
            ["hidden_states", "residual"],
            text_config.hidden_size
        )
        self.to(dtype=torch.bfloat16)
        
    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str, **kwargs):
        """加载预训练模型"""
        # 确保 vllm_config 被正确传入
        vllm_config = kwargs.pop("vllm_config", None)
        if vllm_config is None:
            raise ValueError("vllm_config 参数未提供，无法初始化模型")
        # 确保配置中包含正确的 attention 相关配置
        model_config = vllm_config.model_config.hf_config
        logger.info(f"Model config attention params:")
        logger.info(f"- num_attention_heads: {model_config.num_attention_heads}")
        logger.info(f"- num_key_value_heads: {model_config.num_key_value_heads}")
        # 提取相关配置参数
        torch_dtype = kwargs.pop("torch_dtype", torch.bfloat16)
        device_map = kwargs.pop("device_map", "auto")
        low_cpu_mem_usage = kwargs.pop("low_cpu_mem_usage", True)
        load_in_8bit = kwargs.pop("load_in_8bit", False)

        # 初始化模型
        logger.info(f"Loading model configuration from: {pretrained_model_name_or_path}")
        logger.info(f"Initializing TextModel with dtype={torch_dtype}, device_map={device_map}")
        model = cls(
            text_model_name_or_path=pretrained_model_name_or_path,
            torch_dtype=torch_dtype,
            low_cpu_mem_usage=low_cpu_mem_usage,
            device_map=device_map,
            load_in_8bit=load_in_8bit,
            vllm_config=vllm_config,
        )

        # 先检查index文件
        index_path = os.path.join(pretrained_model_name_or_path, "pytorch_model.bin.index.json")
        logger.info(f"Looking for model index at: {index_path}")

        if os.path.exists(index_path):
            import json
            with open(index_path, 'r') as f:
                index_data = json.load(f)

            logger.info(f"Loading {len(index_data['weight_map'])} weights from index")

            # 使用集合记录已加载的文件
            loaded_files = set()
            weights = []

            # 一次性加载权重
            for name, filename in index_data['weight_map'].items():
                # 避免重复加载同一个文件
                if filename in loaded_files:
                    continue

                weight_path = os.path.join(pretrained_model_name_or_path, filename)
                logger.info(f"Loading weight file: {filename}")

                state_dict = torch.load(weight_path, map_location="cpu", weights_only=True)
                loaded_files.add(filename)

                # 处理此文件中的所有权重
                for weight_name, weight in state_dict.items():
                    weights.append((weight_name, weight))

            logger.info(f"Successfully collected {len(weights)} weights from {len(loaded_files)} files")

            if weights:
                model.load_weights(weights)
                logger.info("All weights loaded successfully")
            else:
                logger.warning("No weights were collected!")

        return model
    
    def forward(
        self,
        input_ids: Optional[torch.Tensor],
        positions: torch.Tensor,
        kv_caches: List[torch.Tensor],
        attn_metadata: AttentionMetadata,
        intermediate_tensors: Optional[IntermediateTensors] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
    ) -> Union[torch.Tensor, IntermediateTensors]:
        logger.info(f"Starting TextModel forward pass...")
        logger.info(f"Input IDs shape: {input_ids.shape if input_ids is not None else 'None'}")
        logger.info(f"TextModel forward - inputs_embeds: {inputs_embeds.shape if inputs_embeds is not None else None}")
        logger.info(f"TextModel forward - intermediate_tensors: {intermediate_tensors is not None}")
        logger.info(f"Positions shape: {positions.shape}, dtype: {positions.dtype}")
        logger.info(f"KV Caches count: {len(kv_caches)}, shapes: {[k.shape for k in kv_caches]}")
        #logger.info(f"Attention metadata keys: {list(attn_metadata.keys())}")

        if input_ids is not None:
            logger.info(f"Input IDs dtype: {input_ids.dtype}, device: {input_ids.device}")
            hidden_states = self.embed_tokens(input_ids)
        elif inputs_embeds is not None:
            hidden_states = inputs_embeds
            logger.info(f"Using inputs_embeds directly, shape: {inputs_embeds.shape}")
        else:
            raise ValueError("Either input_ids or inputs_embeds must be provided.")

        logger.info(f"Initial hidden states shape: {hidden_states.shape}, dtype: {hidden_states.dtype}")
        logger.info(f"- Hidden states shape: {hidden_states.shape}")
        logger.info(f"- Mean: {hidden_states.mean():.6f}")
        logger.info(f"- Std: {hidden_states.std():.6f}")
        logger.info(f"- Max: {hidden_states.max():.6f}")
        logger.info(f"- Min: {hidden_states.min():.6f}")
        residual = None

        for i, layer in enumerate(self.layers):
            logger.info(f"=== Processing Layer {i} ===")
            logger.info(f"Before Layer {i}:")
            logger.info(f"- Hidden states shape: {hidden_states.shape}")
            logger.info(f"- Mean: {hidden_states.mean():.6f}")
            logger.info(f"- Std: {hidden_states.std():.6f}")
            logger.info(f"- Max: {hidden_states.max():.6f}")
            logger.info(f"- Min: {hidden_states.min():.6f}")
            logger.info(f"- Residual: {'None' if residual is None else residual.shape}")
            hidden_states, residual = layer(
                positions=positions,
                hidden_states=hidden_states,
                kv_cache=kv_caches[i],
                attn_metadata=attn_metadata,
                residual=residual
            )


            logger.info(f"After Layer {i}:")
            logger.info(f"- Hidden states shape: {hidden_states.shape}")
            logger.info(f"- Mean: {hidden_states.mean():.6f}")
            logger.info(f"- Std: {hidden_states.std():.6f}")
            logger.info(f"- Max: {hidden_states.max():.6f}")
            logger.info(f"- Min: {hidden_states.min():.6f}")
            logger.info(f"- Non-zero elements: {torch.count_nonzero(hidden_states).item()}")
            logger.info(f"- Residual shape: {residual.shape if residual is not None else 'None'}")
        if hasattr(self, "norm"):
            logger.info("Before RMSNorm:")
            logger.info(f"- Hidden states shape: {hidden_states.shape}")
            logger.info(f"- Mean: {hidden_states.mean():.6f}")
            logger.info(f"- Std: {hidden_states.std():.6f}")
            logger.info(f"- Max: {hidden_states.max():.6f}")
            logger.info(f"- Min: {hidden_states.min():.6f}")
            logger.info(f"- Non-zero elements: {torch.count_nonzero(hidden_states).item()}")
            # 添加一些示例值
            logger.info(f"- Sample values (first 5): {hidden_states[0, :5]}")

            # 打印 norm 层的权重信息
            logger.info("RMSNorm layer info:")
            logger.info(f"- Weight shape: {self.norm.weight.shape}")
            logger.info(f"- Weight mean: {self.norm.weight.mean():.6f}")
            logger.info(f"- Weight std: {self.norm.weight.std():.6f}")
            #logger.info(f"- Epsilon: {self.norm.eps}")

            logger.info(f"Applying final RMSNorm...")
            hidden_states = self.norm(hidden_states)

            logger.info("After RMSNorm:")
            logger.info(f"- Hidden states shape: {hidden_states.shape}")
            logger.info(f"- Mean: {hidden_states.mean():.6f}")
            logger.info(f"- Std: {hidden_states.std():.6f}")
            logger.info(f"- Max: {hidden_states.max():.6f}")
            logger.info(f"- Min: {hidden_states.min():.6f}")
            logger.info(f"- Non-zero elements: {torch.count_nonzero(hidden_states).item()}")
            logger.info(f"- Sample values (first 5): {hidden_states[0, :5]}")

        logger.info(f"Hidden states shape after text model: {hidden_states.shape}")

        return hidden_states

    def get_input_embeddings(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.embed_tokens(input_ids)

    def compute_logits(self, hidden_states: torch.Tensor, sampling_metadata: SamplingMetadata) -> torch.Tensor:
        """计算 logits 并添加详细的调试信息"""

        # 1. 验证输入
        logger.info(f"Hidden states before compute_logits:")
        logger.info(f"- Shape: {hidden_states.shape}")
        logger.info(f"- Mean: {hidden_states.mean():.6f}")
        logger.info(f"- Std: {hidden_states.std():.6f}")
        logger.info(f"- Device: {hidden_states.device}")
        logger.info(f"- Dtype: {hidden_states.dtype}")
        logger.info(f"Hidden states stats before LM head: min={hidden_states.min()}, max={hidden_states.max()}, non-zero={torch.count_nonzero(hidden_states)}")

        # 2. 验证 LM head
        logger.info(f"LM head weight details:")
        logger.info(f"- Shape: {self.lm_head.weight.shape}")
        logger.info(f"- Mean: {self.lm_head.weight.mean():.6f}")
        logger.info(f"- Std: {self.lm_head.weight.std():.6f}")
        logger.info(f"- Device: {self.lm_head.weight.device}")
        logger.info(f"- Dtype: {self.lm_head.weight.dtype}")

        # 3. 先进行直接的线性变换
        raw_logits = torch.matmul(hidden_states, self.lm_head.weight.t())
        logger.info(f"Raw logits before processor:")
        logger.info(f"- Shape: {raw_logits.shape}")
        logger.info(f"- Mean: {raw_logits.mean():.6f}")
        logger.info(f"- Std: {raw_logits.std():.6f}")

        # 4. 使用 logits_processor 处理
        processed_logits = self.logits_processor(self.lm_head, hidden_states, sampling_metadata)
        logger.info(f"Processed logits stats:")
        logger.info(f"- Shape: {processed_logits.shape}")
        logger.info(f"- Mean: {processed_logits.mean():.6f}")
        logger.info(f"- Std: {processed_logits.std():.6f}")
        logger.info(f"- Sample values: {processed_logits[0, :5]}")  # 打印前几个值

        # 5. 如果处理后的 logits 全为零，使用原始 logits
        '''
        if processed_logits.abs().sum() < 1e-6:
            logger.warning("Processed logits are all zero! Using raw logits instead.")
            return raw_logits'''

        return processed_logits

    def sample(self, logits: torch.Tensor, sampling_metadata: SamplingMetadata) -> SamplerOutput:
        """采样生成"""
        '''a= torch.argmax(logits, dim=-1)
        self.logger.info(f"Computed next_tokens shape: {a}")
        self.logger.info(f"Computed logits shape: {logits[:,:100]}")'''
        return self.sampler(logits, sampling_metadata)
    
    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        params_dict = dict(self.named_parameters())
        logger.info("Starting weight loading process")
        # 1. 首先收集和组织 QKV 权重
        qkv_weights = {}
        for name, weight in weights:
            if any(x in name for x in ['.self_attn.q_proj.', '.self_attn.k_proj.', '.self_attn.v_proj.']):
                layer_idx = name.split('.')[2]  # 提取层号
                if layer_idx not in qkv_weights:
                    qkv_weights[layer_idx] = {}
                if 'q_proj' in name:
                    qkv_weights[layer_idx]['q'] = weight
                elif 'k_proj' in name:
                    qkv_weights[layer_idx]['k'] = weight
                elif 'v_proj' in name:
                    qkv_weights[layer_idx]['v'] = weight

        # 2. 遍历所有层来加载 QKV 权重
        for layer_idx, qkv_dict in qkv_weights.items():
            if len(qkv_dict) == 3:  # 确保有完整的 Q、K、V
                layer = self.layers[int(layer_idx)]
                if hasattr(layer, 'self_attn') and hasattr(layer.self_attn, 'qkv_proj'):
                    qkv_proj = layer.self_attn.qkv_proj
                    logger.info(f"Loading QKV weights for layer {layer_idx}...")

                    # 获取 TP 相关信息
                    tp_rank = get_tensor_model_parallel_rank()
                    tp_size = get_tensor_model_parallel_world_size()

                    # 获取每个分量的大小
                    q_size = qkv_proj.num_heads * qkv_proj.head_size
                    kv_size = qkv_proj.num_kv_heads * qkv_proj.head_size

                    # 1. 拼接 q, k, v 权重
                    q_weight = qkv_dict['q']
                    k_weight = qkv_dict['k']
                    v_weight = qkv_dict['v']

                    # 添加日志,查看权重形状
                    logger.info(f"q_weight shape: {q_weight.shape}")
                    logger.info(f"k_weight shape: {k_weight.shape}")
                    logger.info(f"v_weight shape: {v_weight.shape}")

                    # 拼接q, k, v 的权重
                    qkv_weight = torch.cat([q_weight, k_weight, v_weight], dim=0)
                    logger.info(f"Merged QKV weight shape: {qkv_weight.shape}")

                    # 计算分片大小和索引
                    shard_size = qkv_weight.shape[0] // tp_size
                    start_idx = tp_rank * shard_size

                    # 确保开始索引和分片大小不超出权重范围
                    if start_idx < qkv_weight.shape[0]:
                        weight_shard = qkv_weight.narrow(0, start_idx, min(shard_size, qkv_weight.shape[0] - start_idx))
                    else:
                        logger.warning(f"start_idx {start_idx} is out of weight shape {qkv_weight.shape}, skipping {name_marker} of layer {layer_idx}")
                        continue  # 跳过此权重

                    logger.info(f"Loading merged QKV weight for layer {layer_idx}")
                    logger.info(f"- Original shape: {qkv_weight.shape}")
                    logger.info(f"- Shard shape: {weight_shard.shape}")
                    logger.info(f"- TP rank/size: {tp_rank}/{tp_size}")
                    logger.info(f"- Shard info: size={shard_size}, offset={start_idx}")
                    logger.info(f"- qkv_proj.weight shape: {qkv_proj.weight.shape}")

                    # 2. 直接调用 weight_loader
                    try:
                        #直接使用 weight_loader 加载合并后的权重
                        qkv_proj.weight_loader(qkv_proj.weight, weight_shard)
                        logger.info("Weight loaded successfully using weight_loader")
                    except Exception as e:
                        logger.error(f"Failed to load weight: {e}")
                else:
                    logger.warning(f"Skipping layer {layer_idx} because it does not have self_attn or qkv_proj")

        # 3. 处理其他权重
        embed_weight = None
        for name, weight in weights:
            if any(x in name for x in ['.self_attn.q_proj.', '.self_attn.k_proj.', '.self_attn.v_proj.']):
                continue
            #   添加对 gate_up_proj 和 down_proj  权重的加载
            # 处理 MLP 权重加载
            if 'mlp.gate_up_proj' in name or 'mlp.down_proj' in name:
                layer_idx = name.split('.')[2]  # 获取层索引
                layer = self.layers[int(layer_idx)]

                # 判断是哪种权重
                if 'gate_up_proj' in name and hasattr(layer, 'mlp') and hasattr(layer.mlp, 'gate_up_proj'):
                    target = layer.mlp.gate_up_proj
                    weight_type = 'gate_up_proj'
                elif 'down_proj' in name and hasattr(layer, 'mlp') and hasattr(layer.mlp, 'down_proj'):
                    target = layer.mlp.down_proj
                    weight_type = 'down_proj'
                else:
                    logger.warning(f"Skipping unknown MLP weight: {name}")
                    continue

                logger.info(f"Loading {weight_type} weight for layer {layer_idx}")
                logger.info(f"- Source weight shape: {weight.shape}")
                logger.info(f"- Target weight shape: {target.weight.shape}")

                try:
                    # 使用 weight_loader 如果有的话
                    if hasattr(target, 'weight_loader'):
                        logger.info(f"Loading {weight_type} weight using weight_loader")
                        target.weight_loader(target.weight, weight)
                        logger.info(f"Loaded using weight_loader")
                    else:
                        target.weight.data.copy_(weight)
                        logger.info(f"Loaded using direct copy")

                    # 记录加载后的权重统计信息
                    logger.info(f"Weight loaded successfully:")
                    logger.info(f"- Mean: {target.weight.mean():.6f}")
                    logger.info(f"- Std: {target.weight.std():.6f}")
                    logger.info(f"- Non-zero elements: {torch.count_nonzero(target.weight).item()}")
                    logger.info(f"- Max: {target.weight.max():.6f}")
                    logger.info(f"- Min: {target.weight.min():.6f}")
                except Exception as e:
                    logger.error(f"Failed to load {weight_type} weight: {str(e)}")

                continue

            if 'self_attn.o_proj' in name:
                layer_idx = name.split('.')[2]  # 提取层号
                layer = self.layers[int(layer_idx)]
                if hasattr(layer, 'self_attn') and hasattr(layer.self_attn, 'o_proj'):
                    o_proj = layer.self_attn.o_proj
                    try:
                        o_proj.weight_loader(o_proj.weight, weight)
                        logger.info(f"Loading o_proj weight for layer {layer_idx}")
                        logger.info(f"- o_proj.weight Mean: {o_proj.weight.mean():.6f}")
                        logger.info(f"- o_proj.weight Std: {o_proj.weight.std():.6f}")
                    except Exception as e:
                        logger.error(f"Failed to load o_proj weight: {e}")
                continue

            if name == 'model.embed_tokens.weight' and embed_weight is None:
                embed_weight = weight
                logger.info(f"Found embedding weight with shape: {weight.shape}")
                if hasattr(self.embed_tokens, 'weight'):
                    logger.info("Loading embed_tokens:")
                    logger.info(f"- Target shape: {self.embed_tokens.weight.shape}")
                    logger.info(f"- Source shape: {embed_weight.shape}")

                    # 确保权重正确加载到填充后的张量中
                    if hasattr(self.embed_tokens, 'weight_loader'):
                        logger.info("Using weight_loader for embed_tokens")
                        self.embed_tokens.weight_loader(self.embed_tokens.weight, embed_weight)
                    else:
                        logger.info("Using direct copy for embed_tokens")
                        self.embed_tokens.weight.data[:embed_weight.shape[0]].copy_(embed_weight)
                        if self.embed_tokens.weight.shape[0] > embed_weight.shape[0]:
                            logger.info("Padding remaining embed_tokens weights with zeros")
                            self.embed_tokens.weight.data[embed_weight.shape[0]:].zero_()

                    logger.info(f"Embed tokens loaded successfully")
                    logger.info(f"- Mean: {self.embed_tokens.weight.mean():.6f}")
                    logger.info(f"- Std: {self.embed_tokens.weight.std():.6f}")

                    # 绑定 lm_head 权重
                    if hasattr(self.lm_head, 'weight') and not isinstance(self.lm_head, PPMissingLayer):
                        logger.info("Binding LM head weights to embeddings")
                        self.lm_head.tie_weights(self.embed_tokens)
                        self.lm_head_tied = True  # 更新绑定状态
                        logger.info(f"LM head binding successful")
                        logger.info(f"- Mean: {self.lm_head.weight.mean():.6f}")
                        logger.info(f"- Std: {self.lm_head.weight.std():.6f}")

        # 处理其他权重
        for name, weight in weights:
            if name == 'model.embed_tokens.weight':
                continue  # 已经处理过了

            if name.startswith('model.'):
                model_name = name.replace('model.', '')
                if hasattr(self.model, 'load_weights'):
                    self.model.load_weights([(model_name, weight)])
            elif name.startswith('lm_head'):
                # 只有在未绑定权重时才需要单独加载 lm_head
                if not getattr(self, 'lm_head_tied', False):  # 使用 getattr 安全地检查绑定状态
                    lm_head_name = name.replace('lm_head.', '')
                    if hasattr(self.lm_head, 'load_weights'):
                        self.lm_head.load_weights([(lm_head_name, weight)])
            else:
                if name in params_dict:
                    param = params_dict[name]
                    if hasattr(param, "weight_loader"):
                        param.weight_loader(param, weight)
                    else:
                        param.data.copy_(weight)
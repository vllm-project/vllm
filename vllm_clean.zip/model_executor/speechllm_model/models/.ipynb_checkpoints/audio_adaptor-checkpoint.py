'''audio_adapter'''
from typing import Optional, List, Tuple, Dict, Union
from dataclasses import dataclass

import os
import logging
import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers.activations import ACT2FN
from transformers.modeling_utils import PreTrainedModel
from transformers.modeling_outputs import BaseModelOutput
from transformers.configuration_utils import PretrainedConfig
from model.configuration.configuration_speechllm import AdaptorConfig
WEIGHTS_NAME = "adapter_model.bin"
class AdaptorMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        print(config)
        self.config = config
        self.activation_fn = ACT2FN[config.hidden_act]
        self.fc1 = nn.Linear(config.hidden_size, config.intermediate_size)
        self.fc2 = nn.Linear(config.intermediate_size, config.hidden_size)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.fc1(hidden_states)
        hidden_states = self.activation_fn(hidden_states)
        hidden_states = self.fc2(hidden_states)
        return hidden_states


class AdaptorAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.embed_dim = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.embed_dim // self.num_heads
        if self.head_dim * self.num_heads != self.embed_dim:
            raise ValueError(f"embed_dim must be divisible by num_heads "
                             f"got (`embed_dim`: {self.embed_dim} and `num_heads`: {self.num_heads}).")
        self.scale = self.head_dim**-0.5
        self.dropout = nn.Dropout(config.attention_dropout)
        self.qkv = nn.Linear(self.embed_dim, 3 * self.embed_dim, bias=False)
        if config.qkv_bias:
            q_bias = nn.Parameter(torch.zeros(self.embed_dim))
            v_bias = nn.Parameter(torch.zeros(self.embed_dim))
        else:
            q_bias = None
            v_bias = None
        if q_bias is not None:
            qkv_bias = torch.cat((q_bias, torch.zeros_like(v_bias, requires_grad=False), v_bias))
            self.qkv.bias = nn.Parameter(qkv_bias)
        self.projection = nn.Linear(self.embed_dim, self.embed_dim)

    def _shape(self, tensor: torch.Tensor, seq_len: int, bsz: int):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Input shape: Batch x Time x Channel"""
        bsz, tgt_len, embed_dim = hidden_states.size()
        mixed_qkv = self.qkv(hidden_states)
        mixed_qkv = mixed_qkv.reshape(bsz, tgt_len, 3, self.num_heads, embed_dim // self.num_heads)
        mixed_qkv = mixed_qkv.permute(2, 0, 3, 1, 4)
        # [B, H, T, F]
        query_states, key_states, value_states = mixed_qkv[0], mixed_qkv[1], mixed_qkv[2]
        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_states, key_states.transpose(-1, -2))
        attention_scores = attention_scores * self.scale
        # Normalize the attention scores to probabilities
        if attention_mask is not None:
            attention_scores = attention_scores.masked_fill(~attention_mask, -torch.finfo(attention_scores.dtype).max)
        attention_probs = nn.functional.softmax(attention_scores, dim=-1)
        attention_probs = self.dropout(attention_probs)
        context_layer = torch.matmul(attention_probs, value_states).permute(0, 2, 1, 3)
        new_context_layer_shape = context_layer.size()[:-2] + (self.embed_dim,)
        context_layer = context_layer.reshape(new_context_layer_shape)
        output = self.projection(context_layer)
        outputs = (output, attention_probs) if output_attentions else (output, None)
        return outputs


class AdaptorTransformerLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.embed_dim = config.hidden_size
        self.self_attn = AdaptorAttention(config)
        self.layer_norm1 = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)
        self.mlp = AdaptorMLP(config)
        self.layer_norm2 = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.FloatTensor]:
        residual = hidden_states
        hidden_states = self.layer_norm1(hidden_states)
        hidden_states, attn_weights = self.self_attn(
            hidden_states = hidden_states,
            attention_mask = attention_mask,
            output_attentions=output_attentions
        )
        hidden_states = hidden_states + residual
        residual = hidden_states
        hidden_states = self.layer_norm2(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = hidden_states + residual
        outputs = (hidden_states, )
        if output_attentions:
            outputs += (attn_weights, )
        return outputs

class AdaptorModel(PreTrainedModel):
    config_class = AdaptorConfig
    main_input_names = "hidden_features"
    def __init__(self, config: AdaptorConfig):
        super().__init__(config)
        self.config = config
        self.embed_dim = config.hidden_size
        self.output_size = config.projection_size
        self.projection = nn.Linear(self.embed_dim, self.output_size)
        print("config.num_hidden_layers:", config.num_hidden_layers)
        if not self.config.only_use_projection:
            self.layers = nn.ModuleList([AdaptorTransformerLayer(config) for _ in range(config.num_hidden_layers)])
            self.out_norm = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)
    
    def forward(
        self,
        hidden_features: Optional[torch.FloatTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None
    ) -> Union[Tuple, BaseModelOutput]:
        return_dict = return_dict if return_dict != None else self.config.use_return_dict
        if self.config.only_use_projection:
            hidden_states = self.projection(hidden_features)
            encoder_states = None
            all_attentions = None
        else:
            output_attentions = output_attentions if output_attentions != None  else self.config.output_attentions
            output_hidden_states = output_hidden_states if output_hidden_states != None  else self.config.output_hidden_states
            encoder_states = () if output_hidden_states else None
            all_attentions = () if output_attentions else None
            hidden_states = hidden_features
            for idx, encoder_layer in enumerate(self.layers):
                if output_hidden_states:
                    encoder_states = encoder_states + (hidden_states, )
                # gradient checkpoint not implemented here
                layer_outputs = encoder_layer(
                    hidden_states,
                    attention_mask,
                    output_attentions = output_attentions
                )
                hidden_states = layer_outputs[0]
                if output_attentions:
                    all_attentions = all_attentions + (layer_outputs[1], )
            if output_hidden_states:
                encoder_states = encoder_states + (hidden_states, )
            hidden_states = self.out_norm(hidden_states)
            hidden_states = self.projection(hidden_states)
        if not return_dict:
            return tuple(v for v in [hidden_states, encoder_states, all_attentions] if v is not None)
        return BaseModelOutput(last_hidden_state=hidden_states, hidden_states=encoder_states, attentions=all_attentions).last_hidden_state
    
    def save_pretrain(self, save_directory, **kwargs):
        if os.path.isfile(save_directory):
            raise ValueError(f"Provided path ({save_directory}) should be a directory, not a file")
        os.makedirs(save_directory, exist_ok=True)
        torch.save(self.state_dict(), os.path.join(save_directory, WEIGHTS_NAME))
    @classmethod
    def from_pretrain(cls, load_directory, config, torch_dtype=torch.float16,
                      device_map=None, **kwargs):
        adaptor_model = cls(config)
        weights_file = os.path.join(load_directory, WEIGHTS_NAME)
        print("adaptor device_map:", device_map)
        # device_map = {'cuda:0': 'cuda:0', 'cuda:1': 'cuda:0', 'cuda:2': 'cuda:0', 'cuda:3': 'cuda:0', 'cuda:4': 'cuda:0', 'cuda:5': 'cuda:0', 'cuda:6': 'cuda:0', 'cuda:7': 'cuda:0'}
        state_dict = torch.load(weights_file, map_location=device_map)
        adaptor_model.load_state_dict(state_dict)
        adaptor_model.to(torch_dtype)

        return adaptor_model

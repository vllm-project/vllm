'''Adapter_Model'''
from typing import Optional

import numpy as np
import os
import torch
import torch.nn as nn

from transformers import AutoModel, AutoFeatureExtractor
from transformers import PretrainedConfig, PreTrainedModel
import librosa


WEIGHTS_NAME = "adapter_model.bin"

class AdaptorModel(nn.Module):

    def __init__(self,
        speech_embed_dim,
        text_embed_dim
    ):
        super().__init__()
        self.adaptor=nn.Linear(speech_embed_dim, text_embed_dim)


    def forward(self, input):
        return self.adaptor(input)


    def _init_weights(self,initializer_range):
        self.adaptor.weight.data.normal_(mean=0.0, std=initializer_range)
        if(self.adaptor.bias is not None):
            self.adaptor.bias.data.zero_()


    def save_pretrain(self, save_directory, **kwargs):
        if os.path.isfile(save_directory):
            raise ValueError(f"Provided path ({save_directory}) should be a directory, not a file")
        os.makedirs(save_directory, exist_ok=True)
        torch.save(self.adaptor.state_dict(), os.path.join(save_directory, WEIGHTS_NAME))


    @classmethod
    def from_pretrain(cls, load_directory, speech_embed_dim=1280,
                      text_embed_dim=4096, torch_dtype=torch.float16,
                      device_map=None, **kwargs):
        adaptor_model = cls(speech_embed_dim, text_embed_dim)
        weights_file = os.path.join(load_directory, WEIGHTS_NAME)
        print("device_map:", device_map)
        device_map = {'cuda:0': 'cuda:0', 'cuda:1': 'cuda:0', 'cuda:2': 'cuda:0', 'cuda:3': 'cuda:0', 'cuda:4': 'cuda:0', 'cuda:5': 'cuda:0', 'cuda:6': 'cuda:0', 'cuda:7': 'cuda:0'}
        state_dict = torch.load(weights_file, map_location=device_map)
        state_dict["adaptor.weight"] = state_dict["weight"]
        state_dict["adaptor.bias"] = state_dict["bias"]
        del state_dict["weight"]
        del state_dict["bias"]

        adaptor_model.load_state_dict(state_dict)
        adaptor_model.to(torch_dtype)

        return adaptor_model

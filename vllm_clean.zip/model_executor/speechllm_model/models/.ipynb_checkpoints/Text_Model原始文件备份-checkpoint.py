'''This file is Text_model.py, 主要用于基座模型的加载和初始化'''
from typing import Optional, Dict, Union, Any
import numpy as np
import os
import torch
from transformers import (
    AutoModel,
    AutoFeatureExtractor,
    PretrainedConfig,
    PreTrainedModel,
    AutoModelForCausalLM,
    LlamaConfig,
    GenerationConfig,
    WhisperConfig
)

class TextModel(PreTrainedModel):
    """Text Model class that wraps a causal language model for text generation tasks.
    
    This model supports LLaMA and other causal language models, handling configuration
    conversion and generation with proper vocabulary size management.
    """
    
    def __init__(
        self,
        text_model_name_or_path: str,
        torch_dtype: torch.dtype,
        low_cpu_mem_usage: bool,
        device_map: Union[str, Dict[str, Union[int, str, torch.device]]],
        load_in_8bit: bool,
        config: Optional[Union[PretrainedConfig, Dict[str, Any]]] = None
    ):
        def convert_nested_configs(cfg: Union[Dict[str, Any], PretrainedConfig]) -> Union[PretrainedConfig, Dict[str, Any]]:
            if isinstance(cfg, dict):
                # 移除强制设置词表大小的代码
                if cfg.get('model_type') == 'llama':
                    return LlamaConfig(**cfg)
                elif cfg.get('model_type') == 'whisper':
                    return WhisperConfig(**cfg)

                for key in cfg:
                    if isinstance(cfg[key], dict):
                        cfg[key] = convert_nested_configs(cfg[key])
                    elif isinstance(cfg[key], list):
                        cfg[key] = [
                            convert_nested_configs(item) if isinstance(item, dict) else item 
                            for item in cfg[key]
                        ]
            return cfg

        # Handle configuration processing
        if isinstance(config, dict):
            config = convert_nested_configs(config)
        else:
            for attr in ['text_config', 'speech_config', 'decoder', 'encoder']:
                if hasattr(config, attr):
                    value = getattr(config, attr)
                    if isinstance(value, dict):
                        setattr(config, attr, convert_nested_configs(value))
            
        
        super().__init__(config)
        
        self.model_path = text_model_name_or_path
        if text_model_name_or_path is not None:
            try:
                self.text_model = AutoModelForCausalLM.from_pretrained(
                    pretrained_model_name_or_path=text_model_name_or_path,
                    torch_dtype=torch_dtype,
                    low_cpu_mem_usage=True,
                    device_map=device_map,
                    load_in_8bit=load_in_8bit,
                    config=config
                )
                
                
            except Exception as e:
                raise RuntimeError(f"Failed to load text model: {e}")

    def save_pretrain(self, save_directory: str, **kwargs) -> None:
        """Save the model to a directory."""
        if os.path.isfile(save_directory):
            raise ValueError(f"Provided path ({save_directory}) should be a directory, not a file")
        os.makedirs(save_directory, exist_ok=True)
        self.text_model.save_pretrained(save_directory, safe_serialization=False)

    def forward(
        self,
        inputs_embeds: torch.Tensor,
        attention_mask: torch.Tensor,
        past_key_values: Optional[torch.Tensor],
        labels: Optional[torch.Tensor],
        use_cache: bool,
        return_dict: bool,
    ):
        """执行模型的前向传播，返回基础模型的输出。"""
        return self.text_model(
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            labels=labels,
            use_cache=use_cache,
            return_dict=return_dict,
            output_hidden_states=True  # 始终返回隐藏状态
        )

    def generate(
        self,
        inputs_embeds: torch.Tensor,
        attention_mask: torch.Tensor,
        generation_config: Union[GenerationConfig, Dict[str, Any]],
        logits_processor: Optional[Any] = None,
        stopping_criteria: Optional[Any] = None,
        prefix_allowed_tokens_fn: Optional[Any] = None,
        synced_gpus: Optional[bool] = None,
        **kwargs
    ):
        """Generate text based on input embeddings."""
        if isinstance(generation_config, dict):
            generation_config = GenerationConfig(**generation_config)

        return self.text_model.generate(
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            generation_config=generation_config,
            logits_processor=logits_processor,
            stopping_criteria=stopping_criteria,
            prefix_allowed_tokens_fn=prefix_allowed_tokens_fn,
            synced_gpus=synced_gpus,
            **kwargs
        )

    def gradient_checkpointing_enable(self) -> None:
        """Enable gradient checkpointing."""
        self.text_model.gradient_checkpointing_enable()

    def get_input_embeddings(self) -> torch.nn.Module:
        """Get the input embeddings layer."""
        return self.text_model.get_input_embeddings()

    def set_input_embeddings(self, new_embeddings: torch.nn.Module) -> None:
        """Set new input embeddings."""
        self.text_model.set_input_embeddings(new_embeddings)

    def get_output_embeddings(self) -> torch.nn.Module:
        """Get the output embeddings layer."""
        return self.text_model.get_output_embeddings()

    def set_output_embeddings(self, new_embeddings: torch.nn.Module) -> None:
        """Set new output embeddings."""
        self.text_model.set_output_embeddings(new_embeddings)

    def resize_token_embeddings(self, new_num_tokens: int) -> torch.nn.Module:
        """Resize token embeddings to a new size."""
        return self.text_model.resize_token_embeddings(new_num_tokens)
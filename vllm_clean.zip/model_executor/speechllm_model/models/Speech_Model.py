'''Speech Model for VLLM'''
from typing import Optional, Union, Dict
import os
import torch
import torch.nn as nn
from transformers import AutoModel, WhisperModel, WhisperConfig
import logging
logger = logging.getLogger("speechllm")

class SpeechModel(nn.Module):
    def __init__(
            self,
            speech_model_name_or_path: str,
            torch_dtype: torch.dtype = torch.float16,
            device_map: Union[str, Dict[str, Union[int, str, torch.device]]] = "auto",
            config: Optional[WhisperConfig] = None,
            use_pooling: bool = True
        ):
        super().__init__()

        self.speech_model_name_or_path = speech_model_name_or_path
        self.torch_dtype = torch_dtype
        # 如果传入的是字符串 "cuda" 或 "cpu" 则直接构造 device，否则可以自行判断
        self.device = torch.device(device_map if isinstance(device_map, str) else "cuda")
        self.use_pooling = use_pooling
        self.config = config

        logger.info("Loading SpeechModel with AutoModel.")
        # 如果用户提供了 WhisperConfig，就加载 WhisperModel；否则自动加载
        if self.config:
            logger.info("Switching to WhisperModel due to provided config.")
            self.speech_model = WhisperModel.from_pretrained(
                self.speech_model_name_or_path,
                config=self.config,
                torch_dtype=self.torch_dtype,
                device_map=self.device
            )
        else:
            self.speech_model = AutoModel.from_pretrained(
                self.speech_model_name_or_path,
                torch_dtype=self.torch_dtype,
                device_map=self.device
            )

        logger.info(f"SpeechModel loaded successfully from {speech_model_name_or_path}.")

        # 初始化 pooling，和原始 SpeechModel 中一致
        if self.use_pooling:
            self.avg_pool = nn.AvgPool1d(kernel_size=2, stride=2, padding=0)

    def forward(self, audio: torch.Tensor) -> torch.Tensor:
        """
        与原始 speech model 逻辑保持一致：只接受一份音频特征，不传多余的参数。
        1. 如果是普通的 AutoModel (如 Wav2Vec2, Hubert 等)，可以用 get_encoder()(...) 获取特征。
        2. 如果是 WhisperModel，则通过 encoder(...) 获取特征。
        """
        # 保证音频特征是正确的数据类型
        audio = audio.to(dtype=self.torch_dtype)

        # 根据是否是 WhisperModel 来决定调用的 API
        if isinstance(self.speech_model, WhisperModel):
            # WhisperModel: 使用 .encoder(...) 
            encoder_outputs = self.speech_model.encoder(audio).last_hidden_state
        else:
            # 其他类型的模型 (AutoModel): 使用 get_encoder()
            encoder_outputs = self.speech_model.get_encoder()(audio).last_hidden_state

        # 如果需要做 pooling
        if self.use_pooling:
            # 原始 speech model pooling 逻辑
            # encoder_outputs shape: [batch_size, seq_len, hidden_size]
            encoder_outputs = encoder_outputs.transpose(1, 2)
            encoder_outputs = self.avg_pool(encoder_outputs)
            encoder_outputs = encoder_outputs.transpose(1, 2)

        return encoder_outputs

    def save_pretrain(self, save_directory: str, **kwargs):
        """
        保留保存逻辑，与原始 speech model 一致
        """
        if os.path.isfile(save_directory):
            raise ValueError(f"Provided path ({save_directory}) should be a directory, not a file")
        os.makedirs(save_directory, exist_ok=True)
        self.speech_model.save_pretrained(save_directory, safe_serialization=False)
    
    @classmethod
    def from_pretrain(cls, load_directory: str, **kwargs):
        """
        保留从本地路径加载预训练模型的逻辑
        """
        torch_dtype = kwargs.get("torch_dtype", torch.float16)
        device_map = kwargs.get("device_map", "auto")
        config_path = os.path.join(load_directory, "config.json")
        if os.path.exists(config_path):
            # 如果存在 Whisper 的 config，就加载 WhisperConfig
            config = WhisperConfig.from_pretrained(config_path)
            logger.info("Found WhisperConfig when loading from_pretrain.")
        else:
            config = None

        # 创建模型实例
        model = cls(
            speech_model_name_or_path=load_directory,
            torch_dtype=torch_dtype,
            device_map=device_map,
            config=config,
            use_pooling=kwargs.get("use_pooling", True)
        )
        return model


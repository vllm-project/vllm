""" VisualCLA model configuration"""

from transformers.configuration_utils import PretrainedConfig
from transformers.utils import logging
from typing import Union, Dict
import os
logger = logging.get_logger(__name__)


class SpeechLlmConfig(PretrainedConfig):

    model_type = "speechllm"
    is_composition = True

    def __init__(
        self,
        text_config: Union[PretrainedConfig, Dict] = None,
        speech_config: Union[PretrainedConfig, Dict] = None,
        initializer_range=0.02,
        layer_norm_eps=1e-12,
        use_visual_resampler=False,
        visual_resampler_config=None,
        **kwargs):
        super().__init__(**kwargs)

        if text_config:
            if isinstance(text_config,PretrainedConfig):
                text_config = text_config.to_dict()
        self.text_config = text_config

        if speech_config:
            if isinstance(speech_config, PretrainedConfig):
                speech_config = speech_config.to_dict()
        self.speech_config = speech_config

        self.initializer_range=initializer_range
        self.layer_norm_eps=layer_norm_eps

        self.use_visual_resampler = use_visual_resampler
        self.visual_resampler_config = visual_resampler_config


class AdaptorConfig(PretrainedConfig):
    model_type = "adaptor"
    def __init__(
        self,
        hidden_size = 1280,
        intermediate_size =  5120,
        num_hidden_layers = 2,
        num_attention_heads = 20,
        hidden_act = "gelu",
        layer_norm_eps = 0.00001,
        attention_dropout = 0.0,
        qkv_bias = True,
        projection_size = 4096,
        only_use_projection = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.hidden_act = hidden_act
        self.layer_norm_eps = layer_norm_eps
        self.attention_dropout = attention_dropout
        self.qkv_bias = qkv_bias
        self.projection_size = projection_size
        self.only_use_projection = only_use_projection

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: Union[str, os.PathLike], **kwargs):
        cls._set_token_in_kwargs(kwargs)
        config_dict, kwargs = cls.get_config_dict(pretrained_model_name_or_path, **kwargs)
        if config_dict.get("model_type") == "llaaa":
            config_dict = config_dict["adaptor_config"]
        if "model_type" in config_dict and hasattr(config, "model_type") and \
            config_dict["model_dict"] != cls.model_type:
            logger.warning(f"You are using a model of type {config_dict['model_type']} "
                           f"to instantiate a model of type {cls.model_type}. This is not supported "
                           f"for all configurations of models and can yield errors.")
        return cls.from_dict(config_dict, **kwargs)
